// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

package org.chromium.base;

import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;

/**
 * Utility class to use new APIs that were added after ICS (API level 14).
 */
public class SlateApiCompatibilityUtils {
    // Do not instantiate
    private SlateApiCompatibilityUtils() {
    }

    /**
     * @see android.view.View#setBackground(Drawable)
     */
    @SuppressWarnings("deprecation")
    public static void setBackgroundForView(View view, Drawable drawable) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            view.setBackground(drawable);
        } else {
            view.setBackgroundDrawable(drawable);
        }
    }

    public static boolean isDuke() {
        return Build.MODEL.equals("SD4930UR");
    }
}
