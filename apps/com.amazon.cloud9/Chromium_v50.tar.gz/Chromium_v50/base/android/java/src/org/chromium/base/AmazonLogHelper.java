// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

package org.chromium.base;

import org.chromium.base.annotations.CalledByNative;
import org.chromium.base.annotations.JNINamespace;

/**
 * Static logging utility that allows native code to emit logs from Java.
 * This is useful because the native logging utilities do not follow the
 * same code path as the Java ones.
 */
@JNINamespace("base::android::amazon")
public abstract class AmazonLogHelper {
    // Prevent instantiation.
    private AmazonLogHelper() {}

    /**
     * Method to proxy native logging calls through Log.wtf().
     * Like native logging, this records a FATAL-level log, but this method also triggers
     * the TerribleFailureHandler which creates a log that will be uploaded with crash reports.
     *
     * @see <a href="https://issues.amazon.com/IRONBC-662">IRONBC-662</a>
     * @see android.util.Log#TerribleFailureHandler
     */
    @CalledByNative
    public static void wtf(final String tag, final String message) {
        Log.wtf(tag, message);
    }
}