// Copyright 2013 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

package org.chromium.media;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.MediaPlayer;
import android.media.MediaPlayer.TrackInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Base64InputStream;
import android.view.Surface;
import android.widget.Toast;

import org.chromium.base.Log;
import org.chromium.base.annotations.CalledByNative;
import org.chromium.base.annotations.JNINamespace;
import org.chromium.base.metrics.RecordHistogram;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/**
* A wrapper around android.media.MediaPlayer that allows the native code to use it.
* See media/base/android/media_player_bridge.cc for the corresponding native code.
*
*
* NOTES ON WORK-AROUNDS FOR MEDIAPLAYER API CALLS NOT RETURNING WITHIN REASONABLE TIME:
*
* Due to bugs in the media players, the Android MediaPlayer API calls might not return
* within several seconds. To circumvent this on older platforms that will never receive
* bug fixes for the media players, all API calls are executed from a background thread,
* decoupling the MediaPlayer API form the application's main thread.
*
* All API calls are executed serially from a background media thread. From MediaPlayer API's
* point of view, the media thread is application's main thread. It will never see any other
* threads making calls. Each MediaPlayer will have its own thread. The actual media player
* runs in a separate process (/system/bin/media_server) and communicates through IPC, so using
* multiple threads does not impact it negatively.
*
* The goal is to improve the experience for use cases where Silk becomes completely
* unresponsive. An ANR dialog would be presented without the work-arounds, asking user to wait
* or terminate Silk. While media playback will still continue to suffer from existing issues
* (i.e., the player does not respond), the user experience is much improved compares to
* hanging the entire browser.
*
* Each call is given a deadline, and as long as the API calls return without violating
* the deadline, existing behavior does not change and the main thread is blocked for the
* duration of API calls. Returning before actually doing the work would cause the application
* to think MediaPlayer API has already reached some future state, which is not yet the
* case.
*
* When a deadline for an API call is violated, the latch blocking the main thread is allowed
* to open. From this point on, MediaPlayer API calls execute concurrently with the main thread
* and any futher API calls get queued. Getters will return cached last known values. When the
* blocking API call returns (media thread catches up), normal operation is restored and calls
* from main thread will again block until the deadline is violated.
*
* If individual API calls each take a couple of seconds without any individual call violating
* its deadline, and multiple such calls are done from a single method running in main thread,
* bad behavior can still lead to an ANR even without any of the individual calls ever taking
* five seconds.
*
* Real-life scenarios:
* 1) User taps the pause button, but MediaPlayer is buffering and fails to respond. Silk freezes
*    and presents the ANR dialog. User chooses to wait. After several seconds, MediaPlayer starts
*    responding again and seek completes. With this patch, the user interfaces starts responding
*    again after being frozen for four seconds. Seek position indicates the new position, but
*    player actually seeks only after several seconds later.
* 2) Video is playing. User closes the tab and Silk attempts to release the MediaPlayer instance.
*    The API fails to respond in time, Silk freezes completely while the video goes on playing,
*    and the ANR dialog is shown. After choosing to wait, the tab closes after several seconds
*    of waiting and video stops. With this patch, the tab will close immediately, while the video
*    might keep playing in the background for several seconds (audible, not visible).
*/

@JNINamespace("media")
public class MediaPlayerBridge {

    private static final String TAG = "cr_media";
    private static final boolean ENABLE_TOAST_NOTIFICATIONS = false;

    // Histogram names: prefix + task name, e.g. MediaPlayerBridge.seekTo
    private static final String METRIC_PREFIX_DURATIONS = "MediaPlayerBridge.Duration.";
    private static final String METRIC_PREFIX_RECOVERED_DURATIONS =
            "MediaPlayerBridge.RecoveredDuration.";
    private static final String METRIC_PREFIX_DEADLINE_VIOLATIONS = "MediaPlayerBridge.WasLate.";

    // Local player to forward this to. We don't initialize it here since the subclass might not
    // want it.
    private LoadDataUriTask mLoadDataUriTask;
    private MediaPlayer mPlayer;
    private long mNativeMediaPlayerBridge;
    private DecouplerThread mDecoupler;

    // Gen5 (API level 15) does not yet have MediaPlayer.TrackInfo class.
    enum TrackType {
        TRACK_TYPE_VIDEO,
        TRACK_TYPE_AUDIO
    }

    // Time bound for blocking the main thread.
    private static final int ANR_PREVENTION_DEADLINE_MILLISECONDS = 4500;

    private enum TaskCategory {
        // Internal changes that can be postponed without causing the application to crash or
        // end up in undefined state. Examples: seeking or changing volume.
        IMPACTS_INTERNAL_STATE,
        // State changes that should not be postponed (executed asynchronously),
        // otherwise the application might crash or end up in undefined state.
        // Examples: setting listeners, changing the output surface.
        IMPACTS_EXTERNAL_STATE,
        // For getters that can return the last known value when current data is unavailable
        // due to MediaPlayer API not responding, such as getting current playback position.
        GETTER_FAKEABLE_WITH_LAST_KNOWN
    }

    // From application's point of view the player is gone, but the background thread might
    // still be alive.
    private boolean mBridgeDestroyed;

    // Deadline was violated. Used to avoid consecutive pointless waits, each waiting until
    // the deadline. After the deadline has been violated, futher calls do not wait until
    // the first offending call returns.
    private boolean mPlayerUnresponsive;
    // How many tasks are supposedly completed but are actually still in the queue.
    private int mNumberOfFloatingTasks;

    // There can be multiple media players running concurrently.
    // It's nice to be able to differentiate which log messages came from which instance.
    private static int sInstanceIdentifierOrdinal = 0;
    private int mInstanceIdentifier;

    // Last known return values that will be used instead of real state
    // if the API goes unresponsive:
    private boolean mLastKnownIsPlaying = false;
    private Object mCachedTrackInfo = null;
    // Very unlikely that MediaPlayer API would hang during the first calls to get these,
    // so these can be initialized to zero. They will have actual values if some UI component
    // asks again during a time when MediaPlayer is unresponsive.
    private int mLastKnownCurrentPosition;
    private int mLastKnownDuration;
    private int mLastKnownVideoWidth;
    private int mLastKnownVideoHeight;
    // Mirroring the Chromium defaults, everything is allowed unless something indicates otherwise.
    private AllowedOperations mLastKnownAllowedOperations =
            new AllowedOperations(true, true, true);

    // Warning: risk for memory leaks due to holding a reference to Activity.
    // The background thread must hold a reference to this through implicit reference
    // to it's outer class.
    private Context mContextForToasts;

    public static enum MetricsClassification {
        UserAction
    }

    @CalledByNative
    private static MediaPlayerBridge create(long nativeMediaPlayerBridge) {
        return new MediaPlayerBridge(nativeMediaPlayerBridge);
    }

    protected MediaPlayerBridge(long nativeMediaPlayerBridge) {
        this();
        mNativeMediaPlayerBridge = nativeMediaPlayerBridge;
    }

    protected MediaPlayerBridge() {
        mInstanceIdentifier = sInstanceIdentifierOrdinal++;
        // Warm-up the background executor thread.
        getDecoupler();
    }

    // Called when closing a tab. When switching tabs, player will be released but
    // bridge will not get destroyed. Same bridge can be re-used for multiple players.
    @CalledByNative
    protected void destroy() {
        if (mLoadDataUriTask != null) {
            mLoadDataUriTask.cancel(true);
            mLoadDataUriTask = null;
        }
        mContextForToasts = null;
        // Must be set before notifying the decoupler thread,
        /// otherwise there's a race to see the change.
        mBridgeDestroyed = true;
        mNativeMediaPlayerBridge = 0;
        if (mDecoupler != null) {
            mDecoupler.onPlayerDestroyed();
        }
        mDecoupler = null;
    }

    protected MediaPlayer getLocalPlayer() {
        if (mPlayer == null) {
            mPlayer = new MediaPlayer();
        }
        return mPlayer;
    }

    protected DecouplerThread getDecoupler() {
        // Let the NPE happen if somebody tries to control the media player after it was destroyed.
        if (mDecoupler == null && !mBridgeDestroyed) {
            mDecoupler = new DecouplerThread();
            mDecoupler.setDaemon(true);
            mDecoupler.start();

            try {
                // Wait for looper thread to initialize.
                mDecoupler.mStartedLatch.await();
            } catch (InterruptedException e) {
                logError("Interrupted waiting for Decoupler initialization.");
                // May or may not get lucky and not crash.
            }
        }

        return mDecoupler;
    }

    @CalledByNative
    protected void setSurface(final Surface surface) {
        DecouplerThread decoupler = getDecoupler();
        MediaRunnable mediaTask = new MediaRunnable("setSurface",
                MetricsClassification.UserAction) {
            @Override
            public void run() {
                // Should always set surface to NULL in order to clean up after.
                try {
                    getLocalPlayer().setSurface(surface);
                } catch (IllegalArgumentException e) {
                    Log.e(TAG, "setSurface() attempted to use an invalid surface");
                }
            }
        };

        mediaTask.mCancellingOnDeathWouldLeak = (surface == null);
        decoupler.execute(TaskCategory.IMPACTS_EXTERNAL_STATE, mediaTask);
    }

    @CalledByNative
    protected boolean prepareAsync() {
        final AtomicBoolean success = new AtomicBoolean(false);

        getDecoupler().execute(TaskCategory.IMPACTS_EXTERNAL_STATE,
                new MediaRunnable("prepareAsync") {
                @Override
                public void run() {
                    try {
                        getLocalPlayer().prepareAsync();
                    } catch (IllegalStateException ise) {
                        logError("Unable to prepare MediaPlayer.", ise);
                        return;
                    } catch (Exception e) {
                        // Catch IOException thrown by android MediaPlayer native code.
                        logError("Unable to prepare MediaPlayer.", e);
                        return;
                    }
                    success.set(true);
                }
            });

        return success.get();
    }

    @CalledByNative
    protected boolean isPlaying() {
        final AtomicBoolean playing = new AtomicBoolean(mLastKnownIsPlaying);
        getDecoupler().execute(TaskCategory.GETTER_FAKEABLE_WITH_LAST_KNOWN,
                new MediaRunnable("isPlaying") {
                @Override
                public void run() {
                    playing.set(getLocalPlayer().isPlaying());
                }
            });
        return (mLastKnownIsPlaying = playing.get());
    }

    @CalledByNative
    protected boolean hasVideo() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) return true;
        return hasTrack(TrackType.TRACK_TYPE_VIDEO);
    }

    @CalledByNative
    protected boolean hasAudio() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) return true;
        return hasTrack(TrackType.TRACK_TYPE_AUDIO);
    }

    private boolean hasTrack(final TrackType trackType) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) return true;
        final AtomicBoolean have = new AtomicBoolean(true);

        boolean completed = getDecoupler().execute(TaskCategory.GETTER_FAKEABLE_WITH_LAST_KNOWN,
                new MediaRunnable("hasTrack") {
                @SuppressLint("NewApi")
                @Override
                public void run() {
                    // Cannot just cache the tracks oonce and use the same info for all following
                    // has() calls, because playlists might cause the tracks to change after
                    // moving to the next item on the list.
                    try {
                        mCachedTrackInfo = getLocalPlayer().getTrackInfo();
                    } catch (RuntimeException e) {
                        // This mirrors behavior in existing hasTrack(TrackInfo[], int)
                        // override variant.
                        have.set(true);
                        return;
                    }

                    have.set(hasTrack(mCachedTrackInfo, trackType));
                }
            });

        if (!completed) {
            return hasTrack(mCachedTrackInfo, trackType);
        }
        return have.get();
    }

    @SuppressLint("NewApi")
    private boolean hasTrack(Object trackInfoObj, TrackType trackType) {
        // Gen5 (API level 15) does not yet have TrackInfo class.
        if (trackInfoObj == null) return true;

        try {
            TrackInfo[] trackInfo = (TrackInfo[]) trackInfoObj;
            int androidTrackType = (trackType == TrackType.TRACK_TYPE_VIDEO)
                    ? TrackInfo.MEDIA_TRACK_TYPE_VIDEO : TrackInfo.MEDIA_TRACK_TYPE_AUDIO;

            // HLS media does not have the track info, so we treat them conservatively.
            if (trackInfo.length == 0) return true;

            for (TrackInfo info : trackInfo) {
                // TODO(zqzhang): may be we can have a histogram recording
                // media track types in the future.
                // See http://crbug.com/571411
                if (androidTrackType == info.getTrackType()) return true;
                if (TrackInfo.MEDIA_TRACK_TYPE_UNKNOWN == info.getTrackType()) return true;
            }
        } catch (RuntimeException e) {
            // Exceptions may come from getTrackInfo (IllegalStateException/RuntimeException), or
            // from some customized OS returning null TrackInfos (NullPointerException).
            return true;
        }
        return false;
    }

    @CalledByNative
    protected int getVideoWidth() {
        final AtomicInteger width = new AtomicInteger(mLastKnownCurrentPosition);
        getDecoupler().execute(TaskCategory.GETTER_FAKEABLE_WITH_LAST_KNOWN,
                new MediaRunnable("getVideoWidth") {
                @Override
                public void run() {
                    width.set(getLocalPlayer().getVideoWidth());
                }
            });
        return (mLastKnownVideoWidth = width.get());
    }

    @CalledByNative
    protected int getVideoHeight() {
        final AtomicInteger height = new AtomicInteger(mLastKnownCurrentPosition);
        getDecoupler().execute(TaskCategory.GETTER_FAKEABLE_WITH_LAST_KNOWN,
                new MediaRunnable("getVideoHeight") {
                @Override
                public void run() {
                    height.set(getLocalPlayer().getVideoHeight());
                }
            });
        return (mLastKnownVideoHeight = height.get());
    }

    @CalledByNative
    protected int getCurrentPosition() {
        final AtomicInteger position = new AtomicInteger(mLastKnownCurrentPosition);
        getDecoupler().execute(TaskCategory.GETTER_FAKEABLE_WITH_LAST_KNOWN,
                new MediaRunnable("getCurrentPosition") {
                @Override
                public void run() {
                    position.set(getLocalPlayer().getCurrentPosition());
                }
            });
        return (mLastKnownCurrentPosition = position.get());
    }

    @CalledByNative
    protected int getDuration() {
        final AtomicInteger duration = new AtomicInteger(mLastKnownDuration);
        getDecoupler().execute(TaskCategory.GETTER_FAKEABLE_WITH_LAST_KNOWN,
                new MediaRunnable("getDuration") {
                @Override
                public void run() {
                    duration.set(getLocalPlayer().getDuration());
                }
            });
        return (mLastKnownDuration = duration.get());
    }

    // This will get called after destroy()
    @CalledByNative
    protected void release() {

        MediaRunnable mediaTask = new MediaRunnable("release",
                MetricsClassification.UserAction) {
            @Override
            public void run() {
                getLocalPlayer().release();
            }
        };

        mediaTask.mCancellingOnDeathWouldLeak = true;
        getDecoupler().execute(TaskCategory.IMPACTS_EXTERNAL_STATE, mediaTask);
    }

    @CalledByNative
    protected void setVolume(final double volume) {
        getDecoupler().execute(TaskCategory.IMPACTS_INTERNAL_STATE,
                new MediaRunnable("setVolume", MetricsClassification.UserAction) {
                @Override
                public void run() {
                    getLocalPlayer().setVolume((float) volume, (float) volume);
                }
            });
    }

    @CalledByNative
    protected void start() {
        getDecoupler().execute(TaskCategory.IMPACTS_INTERNAL_STATE,
                new MediaRunnable("start", MetricsClassification.UserAction) {
                @Override
                public void run() {
                    getLocalPlayer().start();
                }
            });
    }

    @CalledByNative
    protected void pause() {
        getDecoupler().execute(TaskCategory.IMPACTS_INTERNAL_STATE,
                new MediaRunnable("pause", MetricsClassification.UserAction) {
                @Override
                public void run() {
                    getLocalPlayer().pause();
                }
            });
    }

    @CalledByNative
    protected void seekTo(final int msec) throws IllegalStateException {
        getDecoupler().execute(TaskCategory.IMPACTS_INTERNAL_STATE,
                new MediaRunnable("seekTo", MetricsClassification.UserAction) {
            @Override
            public void run() {
                getLocalPlayer().seekTo(msec);
            }
        });
    }

    @CalledByNative
    protected boolean setDataSource(
            final Context context, final String url, final String cookies,
            final String userAgent, final boolean hideUrlLog) {
        if (ENABLE_TOAST_NOTIFICATIONS) {
            mContextForToasts = context;
        }

        final Uri uri = Uri.parse(url);
        final HashMap<String, String> headersMap = new HashMap<String, String>();
        if (hideUrlLog) headersMap.put("x-hide-urls-from-log", "true");
        if (!TextUtils.isEmpty(cookies)) headersMap.put("Cookie", cookies);
        if (!TextUtils.isEmpty(userAgent)) headersMap.put("User-Agent", userAgent);
        // The security origin check is enforced for devices above K. For devices below K,
        // only anonymous media HTTP request (no cookies) may be considered same-origin.
        // Note that if the server rejects the request we must not consider it same-origin.
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
            headersMap.put("allow-cross-domain-redirect", "false");
        }

        final AtomicBoolean success = new AtomicBoolean(false);
        getDecoupler().execute(TaskCategory.IMPACTS_EXTERNAL_STATE,
                new MediaRunnable("setDataSource(url)",
                        MetricsClassification.UserAction) {
                @Override
                public void run() {
                    try {
                        getLocalPlayer().setDataSource(context, uri, headersMap);
                        success.set(true);
                    } catch (Exception e) {
                        // To rule out some root cases for black video issues.
                        logError("setDataSource(url) failed", e);
                        return;
                    }
                }
            });

        return success.get();
    }

    @CalledByNative
    protected boolean setDataSourceFromFd(int fd, final long offset, final long length) {
        final ParcelFileDescriptor parcelFd = ParcelFileDescriptor.adoptFd(fd);
        final AtomicBoolean success = new AtomicBoolean(false);
        getDecoupler().execute(TaskCategory.IMPACTS_EXTERNAL_STATE,
                new MediaRunnable("setDataSource(fd)",
                        MetricsClassification.UserAction) {
                @Override
                public void run() {
                    try {
                        getLocalPlayer().setDataSource(parcelFd.getFileDescriptor(), offset,
                                length);
                        parcelFd.close();
                        success.set(true);
                    } catch (IOException e) {
                        // To rule out some root cases for black video issues.
                        logError("setDataSource(fd) failed", e);
                    }
                }
            });

        return success.get();
    }

    @CalledByNative
    protected boolean setDataUriDataSource(final Context context, final String url) {
        if (ENABLE_TOAST_NOTIFICATIONS) {
            mContextForToasts = context;
        }

        if (mLoadDataUriTask != null) {
            mLoadDataUriTask.cancel(true);
            mLoadDataUriTask = null;
        }

        if (!url.startsWith("data:")) return false;
        int headerStop = url.indexOf(',');
        if (headerStop == -1) return false;
        String header = url.substring(0, headerStop);
        final String data = url.substring(headerStop + 1);

        String headerContent = header.substring(5);
        String headerInfo[] = headerContent.split(";");
        if (headerInfo.length != 2) return false;
        if (!"base64".equals(headerInfo[1])) return false;

        mLoadDataUriTask = new LoadDataUriTask(context, data);
        mLoadDataUriTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        return true;
    }

    private class LoadDataUriTask extends AsyncTask<Void, Void, Boolean> {
        private final String mData;
        private final Context mContext;
        private File mTempFile;

        public LoadDataUriTask(Context context, String data) {
            mData = data;
            mContext = context;
        }

        @Override
        protected Boolean doInBackground(Void... params) {
            FileOutputStream fos = null;
            try {
                mTempFile = File.createTempFile("decoded", "mediadata");
                fos = new FileOutputStream(mTempFile);
                InputStream stream = new ByteArrayInputStream(mData.getBytes());
                Base64InputStream decoder = new Base64InputStream(stream, Base64.DEFAULT);
                byte[] buffer = new byte[1024];
                int len;
                while ((len = decoder.read(buffer)) != -1) {
                    fos.write(buffer, 0, len);
                }
                decoder.close();
                return true;
            } catch (IOException e) {
                // To rule out some root cases for black video issues.
                logError("setDataUriDataSource.doInBackground() failed", e);
                return false;
            } finally {
                try {
                    if (fos != null) fos.close();
                } catch (IOException e) {
                    // Can't do anything.
                }
            }
        }

        @Override
        protected void onPostExecute(final Boolean result) {
            if (isCancelled()) {
                deleteFile();
                return;
            }
            getDecoupler().execute(TaskCategory.IMPACTS_EXTERNAL_STATE,
                    new MediaRunnable("setDataSource(data)",
                            MetricsClassification.UserAction) {
                    @Override
                    public void run() {
                        Boolean notifyResult = result;
                        try {
                            getLocalPlayer().setDataSource(mContext, Uri.fromFile(mTempFile));
                        } catch (IOException e) {
                            // To rule out some root cases for black video issues.
                            logError("setDataSource(data) failed", e);
                            notifyResult = false;
                        }

                        deleteFile();
                        // Because of asynchronous decoupling, this task might execute after
                        // native MediaPlayerBridge called destroy().
                        if (mNativeMediaPlayerBridge != 0) {
                            nativeOnDidSetDataUriDataSource(mNativeMediaPlayerBridge, result);
                        }
                    }
                });
        }

        private void deleteFile() {
            if (mTempFile == null) return;
            if (!mTempFile.delete()) {
                // File will be deleted when MediaPlayer releases its handler.
                Log.e(TAG, "Failed to delete temporary file: " + mTempFile);
                assert (false);
            }
        }
    }

    protected void setOnCompletionListener(final MediaPlayer.OnCompletionListener listener) {
        MediaRunnable mediaTask = new MediaRunnable("setOnCompletionListener") {
            @Override
            public void run() {
                getLocalPlayer().setOnCompletionListener(listener);
            }
        };

        mediaTask.mCancellingOnDeathWouldLeak = true;
        getDecoupler().execute(TaskCategory.IMPACTS_EXTERNAL_STATE, mediaTask);
    }

    protected void setOnErrorListener(final MediaPlayer.OnErrorListener listener) {
        MediaRunnable mediaTask = new MediaRunnable("setOnErrorListener") {
            @Override
            public void run() {
                getLocalPlayer().setOnErrorListener(listener);
            }
        };

        mediaTask.mCancellingOnDeathWouldLeak = true;
        getDecoupler().execute(TaskCategory.IMPACTS_EXTERNAL_STATE, mediaTask);
    }

    protected void setOnPreparedListener(final MediaPlayer.OnPreparedListener listener) {
        MediaRunnable mediaTask = new MediaRunnable("setOnPreparedListener") {
            @Override
            public void run() {
                getLocalPlayer().setOnPreparedListener(listener);
            }
        };

        mediaTask.mCancellingOnDeathWouldLeak = true;
        getDecoupler().execute(TaskCategory.IMPACTS_EXTERNAL_STATE, mediaTask);
    }

    protected void setOnSeekCompleteListener(final MediaPlayer.OnSeekCompleteListener listener) {
        getDecoupler().execute(TaskCategory.IMPACTS_EXTERNAL_STATE,
                new MediaRunnable("setOnSeekCompleteListener") {
                @Override
                public void run() {
                    getLocalPlayer().setOnSeekCompleteListener(listener);
                }
            });
    }

    protected void setOnVideoSizeChangedListener(
            final MediaPlayer.OnVideoSizeChangedListener listener) {
        getDecoupler().execute(TaskCategory.IMPACTS_EXTERNAL_STATE,
                new MediaRunnable("setOnVideoSizeChangedListener") {
                @Override
                public void run() {
                    getLocalPlayer().setOnVideoSizeChangedListener(listener);
                }
            });
    }

    protected void setOnBufferingUpdateListener(
            final MediaPlayer.OnBufferingUpdateListener listener) {
        getDecoupler().execute(TaskCategory.IMPACTS_EXTERNAL_STATE,
                new MediaRunnable("setOnBufferingUpdateListener") {
                @Override
                public void run() {
                    getLocalPlayer().setOnBufferingUpdateListener(listener);
                }
            });
    }

    protected static class AllowedOperations {
        private final boolean mCanPause;
        private final boolean mCanSeekForward;
        private final boolean mCanSeekBackward;

        public AllowedOperations(boolean canPause, boolean canSeekForward,
                boolean canSeekBackward) {
            mCanPause = canPause;
            mCanSeekForward = canSeekForward;
            mCanSeekBackward = canSeekBackward;
        }

        @CalledByNative("AllowedOperations")
        private boolean canPause() {
            return mCanPause;
        }

        @CalledByNative("AllowedOperations")
        private boolean canSeekForward() {
            return mCanSeekForward;
        }

        @CalledByNative("AllowedOperations")
        private boolean canSeekBackward() {
            return mCanSeekBackward;
        }
    }

    /**
     * Returns an AllowedOperations object to show all the operations that are
     * allowed on the media player.
     */
    @CalledByNative
    protected AllowedOperations getAllowedOperations() {
        final AtomicReference<AllowedOperations> response =
                new AtomicReference<AllowedOperations>(mLastKnownAllowedOperations);
        getDecoupler().execute(TaskCategory.IMPACTS_EXTERNAL_STATE,
                new MediaRunnable("getAllowedOperations") {
                @Override
                public void run() {
                    response.set(getAllowedOperationsInternal());
                }
            });

        return response.get();
    }

    protected AllowedOperations getAllowedOperationsInternal() {
        MediaPlayer player = getLocalPlayer();
        boolean canPause = true;
        boolean canSeekForward = true;
        boolean canSeekBackward = true;
        try {
            Method getMetadata = player.getClass().getDeclaredMethod(
                    "getMetadata", boolean.class, boolean.class);
            getMetadata.setAccessible(true);
            Object data = getMetadata.invoke(player, false, false);
            if (data != null) {
                Class<?> metadataClass = data.getClass();
                Method hasMethod = metadataClass.getDeclaredMethod("has", int.class);
                Method getBooleanMethod = metadataClass.getDeclaredMethod("getBoolean", int.class);

                int pause = (Integer) metadataClass.getField("PAUSE_AVAILABLE").get(null);
                int seekForward =
                        (Integer) metadataClass.getField("SEEK_FORWARD_AVAILABLE").get(null);
                int seekBackward =
                        (Integer) metadataClass.getField("SEEK_BACKWARD_AVAILABLE").get(null);
                hasMethod.setAccessible(true);
                getBooleanMethod.setAccessible(true);
                canPause = !((Boolean) hasMethod.invoke(data, pause))
                        || ((Boolean) getBooleanMethod.invoke(data, pause));
                canSeekForward = !((Boolean) hasMethod.invoke(data, seekForward))
                        || ((Boolean) getBooleanMethod.invoke(data, seekForward));
                canSeekBackward = !((Boolean) hasMethod.invoke(data, seekBackward))
                        || ((Boolean) getBooleanMethod.invoke(data, seekBackward));
            }
        } catch (NoSuchMethodException e) {
            Log.e(TAG, "Cannot find getMetadata() method: " + e);
        } catch (InvocationTargetException e) {
            Log.e(TAG, "Cannot invoke MediaPlayer.getMetadata() method: " + e);
        } catch (IllegalAccessException e) {
            Log.e(TAG, "Cannot access metadata: " + e);
        } catch (NoSuchFieldException e) {
            Log.e(TAG, "Cannot find matching fields in Metadata class: " + e);
        }
        return new AllowedOperations(canPause, canSeekForward, canSeekBackward);
    }


    private abstract class MediaRunnable implements Runnable {
        // Used to block the main thread until deadline.
        protected CountDownLatch mLatch;

        // This task caused the deadline violation.
        protected boolean mDeadlineViolated = false;
        // This task was executed concurrently with the main thread.
        protected boolean mFloating = false;

        protected String mName;
        // Even when shutting down, this task should not be ignored to avoid leaking anything.
        protected boolean mCancellingOnDeathWouldLeak;
        // Collect metrics only for human-initiated actions.
        protected boolean mCollectDurationMetrics;

        public MediaRunnable(String name) {
            mName = name;
        }

        public MediaRunnable(String name, MetricsClassification metricsClassification) {
            this(name);
            mCollectDurationMetrics = (metricsClassification == MetricsClassification.UserAction);
        }
    }

    private class DecouplerThread extends HandlerThread {
        protected MediaTaskHandler mHandler;
        protected boolean mAbandoned;

        protected final CountDownLatch mStartedLatch = new CountDownLatch(1);

        public DecouplerThread() {
            super("MediaDecouplerThread");
        }

        protected void onPlayerDestroyed() {
            MediaRunnable lightsOffTask = new MediaRunnable("turnOffTheLights") {
                private boolean mWasUnresponsive;
                public MediaRunnable configure(boolean unresponsive) {
                    mWasUnresponsive = unresponsive;
                    return this;
                }
                @Override
                public void run() {
                    if (mWasUnresponsive) {
                        getLocalPlayer().release();
                    }
                    // Calling quitSafely() would require API level 18
                    // but Silk uses level 15 to support Gen5.
                    DecouplerThread.this.quit();
                }
            }.configure(mPlayerUnresponsive);

            lightsOffTask.mCancellingOnDeathWouldLeak = true;
            mHandler.post(lightsOffTask);
        }

        @Override
        protected void onLooperPrepared() {
            Looper looper = getLooper();
            mHandler = new MediaTaskHandler(looper);
            mStartedLatch.countDown();
        }

        public void post(MediaRunnable task) {
            mHandler.post(task);
        }

        public boolean execute(TaskCategory category, MediaRunnable task) {
            if (mPlayerUnresponsive) {
                if (category == TaskCategory.GETTER_FAKEABLE_WITH_LAST_KNOWN) {
                    logError("Task [" + task.mName
                            + "] faked because media thread is blocking.");
                    return false;
                }

                // While MediaPlayer API is failing to respond, all further tasks are posted
                // directly to the execution queue, and completed next once the offending call
                // has returned.
                task.mFloating = true;
                mNumberOfFloatingTasks += 1;
                mHandler.post(task);
                return true;
            }

            task.mLatch = new CountDownLatch(1);
            mHandler.post(task);
            final int deadlineMsec = ANR_PREVENTION_DEADLINE_MILLISECONDS;
            boolean deadlineViolated = true;

            try {
                deadlineViolated = !task.mLatch.await(deadlineMsec, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                logError("Interrupted waiting for task deadline.");
            } finally {
                // Some tasks might never complete (e.g., due to deadlocks),
                // it's not possible to rely on just recording task durations.
                //
                // Best case would be to initially record the task duration as infinite,
                // then update it to actual value when the task completes, but the metrics
                // framework doesn't support anything like that.
                String metricId = METRIC_PREFIX_DEADLINE_VIOLATIONS + task.mName;
                //RecordHistogram.recordEnumeratedHistogram(task.mMetricEnumeration, min, max);
                RecordHistogram.recordBooleanHistogram(metricId, deadlineViolated);
            }

            if (deadlineViolated) {
                mPlayerUnresponsive = true;
                task.mDeadlineViolated = true;
                task.mFloating = true;
                mNumberOfFloatingTasks += 1;
                logError("Task [" + task.mName + "] did not complete before deadline.");

                if (mContextForToasts != null) {
                    Toast toast = Toast.makeText(mContextForToasts, "Media Player is having "
                            + "trouble responding in a timely manner: " + task.mName,
                            Toast.LENGTH_LONG);
                    toast.show();
                }

                // Return, but the posted task is still executing and might still complete.
                // The running task is now blocking any further tasks.
                return false;
            }
            return true;
        }
    }

    class MediaTaskHandler extends Handler {
        private boolean mStopping;

        public MediaTaskHandler(Looper looper) {
            super(looper);
        }

        // This runs from the background media thread.
        @Override
        public void dispatchMessage(Message msg) {
            Runnable task = msg.getCallback();
            if (task == null) {
                super.dispatchMessage(msg);
                return;
            }

            MediaRunnable mediaTask = (MediaRunnable) task;
            final String logTag = "Decoupler.dispatch: [" + mediaTask.mName + "]";

            // Don't execute useless tasks after player has been destroyed.
            if (mBridgeDestroyed) {
                if (mediaTask.mCancellingOnDeathWouldLeak) {
                    logInfo(logTag + ", cleaning up for zombie player");
                } else {
                    logInfo(logTag + ", skipping for zombie player");
                    return;
                }
            }

            long timeBefore = System.currentTimeMillis();
            super.dispatchMessage(msg);
            long timeAfter = System.currentTimeMillis();
            long durationMs = timeAfter - timeBefore;

            if (mediaTask.mCollectDurationMetrics) {
                String metricId = METRIC_PREFIX_DURATIONS + mediaTask.mName;
                RecordHistogram.recordMediumTimesHistogram(metricId, durationMs,
                        TimeUnit.MILLISECONDS);
            }

            if (mediaTask.mDeadlineViolated) {
                String metricId = METRIC_PREFIX_RECOVERED_DURATIONS + mediaTask.mName;
                RecordHistogram.recordMediumTimesHistogram(metricId, durationMs,
                        TimeUnit.MILLISECONDS);
            }

            if (mediaTask.mFloating) {
                mNumberOfFloatingTasks -= 1;

                // Must reset the unresponsive state before opening the latch,
                // otherwise there would be a race with the next task to
                // execute it normally vs. having it floating.
                if (mNumberOfFloatingTasks == 0) {
                    logInfo("Resetting unresponsive state after violated deadline");
                    mPlayerUnresponsive = false;
                }
            }

            if (mediaTask.mLatch != null) {
                // Executing in the background thread. Let the main thread continue.
                mediaTask.mLatch.countDown();
            }
        }
    };

    private void logInfo(String message) {
        Log.i(TAG, getLogInstanceId() + message);
    }

    private void logError(String message) {
        Log.e(TAG, getLogInstanceId() + message);
    }

    private void logError(String message, Throwable e) {
        Log.e(TAG, message + " (exception was thrown)");
    }

    private String getLogInstanceId() {
        return "MediaPlayerBridge/" + mInstanceIdentifier + ": ";
    }

    private native void nativeOnDidSetDataUriDataSource(long nativeMediaPlayerBridge,
                                                        boolean success);
}
