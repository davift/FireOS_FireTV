// Copyright 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

package org.chromium.media;

import android.content.Context;
import android.media.MediaPlayer;

import org.chromium.base.ThreadUtils;
import org.chromium.base.annotations.CalledByNative;
import org.chromium.base.annotations.JNINamespace;

// This class implements all the listener interface for android mediaplayer.
// Callbacks will be sent to the native class for processing.
@JNINamespace("media")
class MediaPlayerListener implements MediaPlayer.OnPreparedListener,
        MediaPlayer.OnCompletionListener,
        MediaPlayer.OnBufferingUpdateListener,
        MediaPlayer.OnSeekCompleteListener,
        MediaPlayer.OnVideoSizeChangedListener,
        MediaPlayer.OnErrorListener {
    // These values are mirrored as enums in media/base/android/media_player_android.h.
    // Please ensure they stay in sync.
    private static final int MEDIA_ERROR_FORMAT = 0;
    private static final int MEDIA_ERROR_DECODE = 1;
    private static final int MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK = 2;
    private static final int MEDIA_ERROR_INVALID_CODE = 3;
    private static final int MEDIA_ERROR_SERVER_DIED = 4;

    // These values are copied from android media player.
    public static final int MEDIA_ERROR_MALFORMED = -1007;
    public static final int MEDIA_ERROR_TIMED_OUT = -110;

    // Used to determine the class instance to dispatch the native call to.
    private long mNativeMediaPlayerListener = 0;
    private final Context mContext;

    private int mBufferedPercent = 0;

    private MediaPlayerListener(long nativeMediaPlayerListener, Context context) {
        mNativeMediaPlayerListener = nativeMediaPlayerListener;
        mContext = context;
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        if (mNativeMediaPlayerListener == 0) return false;

        int errorType;
        switch (what) {
            case MediaPlayer.MEDIA_ERROR_UNKNOWN:
                switch (extra) {
                    case MEDIA_ERROR_MALFORMED:
                        errorType = MEDIA_ERROR_DECODE;
                        break;
                    case MEDIA_ERROR_TIMED_OUT:
                        errorType = MEDIA_ERROR_INVALID_CODE;
                        break;
                    default:
                        errorType = MEDIA_ERROR_FORMAT;
                        break;
                }
                break;
            case MediaPlayer.MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK:
                errorType = MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK;
                break;
            case MediaPlayer.MEDIA_ERROR_SERVER_DIED:
                errorType = MEDIA_ERROR_SERVER_DIED;
                break;
            default:
                // There are some undocumented error codes for android media player.
                // For example, when surfaceTexture got deleted before we setVideoSuface
                // to NULL, mediaplayer will report error -38. These errors should be ignored
                // and not be treated as an error to webkit.
                errorType = MEDIA_ERROR_INVALID_CODE;
                break;
        }

        final int errorTypeClosured = errorType;
        // Running this on the main thread and blocking could lead to a deadlock in the
        // worst case. It could also cause waiting until the MediaPlayerBridge.DecouplerThread
        // hits its deadline for waiting the current task to complete (on the main thread),
        // because the call lead here through a long chain of calls through multiple
        // processes and threads.
        ThreadUtils.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // A dead native listener doesn't care about errors.
                if (mNativeMediaPlayerListener == 0) return;
                nativeOnMediaError(mNativeMediaPlayerListener, errorTypeClosured);
            }
        });
        return true;
    }

    @Override
    public void onVideoSizeChanged(MediaPlayer mp, final int width, final int height) {
        ThreadUtils.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mNativeMediaPlayerListener == 0) return;
                nativeOnVideoSizeChanged(mNativeMediaPlayerListener, width, height);
            }
        });
    }

    @Override
    public void onSeekComplete(MediaPlayer mp) {
        ThreadUtils.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mNativeMediaPlayerListener == 0) return;
                nativeOnSeekComplete(mNativeMediaPlayerListener);
            }
        });
    }

    @Override
    public void onBufferingUpdate(MediaPlayer mp, final int percent) {
        if (percent == mBufferedPercent) {
            return;
        }

        mBufferedPercent = percent;
        ThreadUtils.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mNativeMediaPlayerListener == 0) return;
                nativeOnBufferingUpdate(mNativeMediaPlayerListener, percent);
            }
        });
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        ThreadUtils.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mNativeMediaPlayerListener == 0) return;
                nativeOnPlaybackComplete(mNativeMediaPlayerListener);
            }
        });
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        ThreadUtils.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mNativeMediaPlayerListener == 0) return;
                nativeOnMediaPrepared(mNativeMediaPlayerListener);
            }
        });
    }

    // Ran from the main thread. All the callbacks are notified from the media thread.
    @CalledByNative
    private static MediaPlayerListener create(long nativeMediaPlayerListener,
            Context context, MediaPlayerBridge mediaPlayerBridge) {
        final MediaPlayerListener listener =
                new MediaPlayerListener(nativeMediaPlayerListener, context);
        if (mediaPlayerBridge != null) {
            mediaPlayerBridge.setOnBufferingUpdateListener(listener);
            mediaPlayerBridge.setOnCompletionListener(listener);
            mediaPlayerBridge.setOnErrorListener(listener);
            mediaPlayerBridge.setOnPreparedListener(listener);
            mediaPlayerBridge.setOnSeekCompleteListener(listener);
            mediaPlayerBridge.setOnVideoSizeChangedListener(listener);
        }
        return listener;
    }

    @CalledByNative
    private void destroy() {
        // Passivate and avoid crashes/ANRs: MAGMA-2874.
        mNativeMediaPlayerListener = 0;
    }

    /**
     * See media/base/android/media_player_listener.cc for all the following functions.
     */
    private native void nativeOnMediaError(
            long nativeMediaPlayerListener,
            int errorType);

    private native void nativeOnVideoSizeChanged(
            long nativeMediaPlayerListener,
            int width, int height);

    private native void nativeOnBufferingUpdate(
            long nativeMediaPlayerListener,
            int percent);

    private native void nativeOnMediaPrepared(long nativeMediaPlayerListener);

    private native void nativeOnPlaybackComplete(long nativeMediaPlayerListener);

    private native void nativeOnSeekComplete(long nativeMediaPlayerListener);

    private native void nativeOnMediaInterrupted(long nativeMediaPlayerListener);
}
