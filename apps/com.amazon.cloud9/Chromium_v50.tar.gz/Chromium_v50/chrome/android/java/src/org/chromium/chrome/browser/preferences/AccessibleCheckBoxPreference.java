// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Copyright 2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

package org.chromium.chrome.browser.preferences;

import android.content.Context;
import android.preference.CheckBoxPreference;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

import org.chromium.chrome.R;

/**
 * This is an Amazon-only class that cannot be upstreamed in its current state. See BROWAPP-641.
 *
 * A checkbox preference that sets its content description to describe its state, allowing the
 * screen reader to read out the state of the checkbox when it is selected or modified.
 */
public class AccessibleCheckBoxPreference extends CheckBoxPreference {
    /**
     * Constructor for inflating from XML.
     */
    public AccessibleCheckBoxPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onBindView(View view) {
        super.onBindView(view);

        final String stateDescription = isChecked()
                ? getContext().getString(R.string.preference_checkbox_on)
                : getContext().getString(R.string.preference_checkbox_off);
        view.setContentDescription(PreferenceContentDescriptionGenerator.generate(
                (TextView) view.findViewById(android.R.id.title),
                (TextView) view.findViewById(android.R.id.summary), stateDescription));
    }
}
