// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

package org.chromium.chrome.browser;

import android.view.Menu;

import org.chromium.chrome.browser.compositor.CompositorViewHolder;
import org.chromium.chrome.browser.compositor.layouts.content.TabContentManager;
import org.chromium.chrome.browser.fullscreen.ChromeFullscreenManager;
import org.chromium.chrome.browser.init.AsyncInitializationActivity;
import org.chromium.chrome.browser.snackbar.SnackbarManager.SnackbarManageable;
import org.chromium.chrome.browser.tab.Tab;
import org.chromium.chrome.browser.tabmodel.TabCreatorManager;
import org.chromium.chrome.browser.tabmodel.TabModel;
import org.chromium.chrome.browser.tabmodel.TabModelSelector;
import org.chromium.ui.base.WindowAndroid;

/**
 * An interface to that supports returning a {@link TabModelSelector}, a
 * {@link TabCreatorManager.TabCreator} and various Activity methods. This
 * interface was introduced in order to provide a set of interfaces that
 * SlateActivity could implement so that various ChromeActivity dependents can
 * function correctly.
 */
public abstract class ChromiumActivity extends AsyncInitializationActivity
        implements TabCreatorManager, SnackbarManageable {
    /**
     * Gets the {@link TabContentManager} instance which holds snapshots of the tabs in this model.
     * @return The thumbnail cache, possibly null.
     */
    public abstract TabContentManager getTabContentManager();

    /**
     * @return The {@link TabModelSelector} belonging to the manager.
     */
    public abstract TabModelSelector getTabModelSelector();

    /**
     * Callback after UpdateMenuItemHelper#checkForUpdateOnBackgroundThread is complete.
     * @param updateAvailable Whether an update is available.
     */
    public abstract void onCheckForUpdate(boolean updateAvailable);

    /**
     * @return Whether the app menu should be shown.
     */
    public abstract boolean shouldShowAppMenu();

    /**
     * @return Whether the activity is in overview mode.
     */
    public abstract boolean isInOverviewMode();

    /**
     * Gets the current (inner) TabModel.  This is a convenience function for
     * getModelSelector().getCurrentModel().  It is *not* equivalent to the former getModel()
     * @return Never null, if modelSelector or its field is uninstantiated returns a
     *         {@link EmptyTabModel} singleton
     */
    public abstract TabModel getCurrentTabModel();

    /**
     * Returns the tab being displayed by this ChromeActivity instance. This allows differentiation
     * between ChromeActivity subclasses that swap between multiple tabs (e.g. ChromeTabbedActivity)
     * and subclasses that only display one Tab (e.g. FullScreenActivity and DocumentActivity).
     *
     * The default implementation grabs the tab currently selected by the TabModel, which may be
     * null if the Tab does not exist or the system is not initialized.
     */
    public abstract Tab getActivityTab();

    /**
     * @return A casted version of {@link #getApplication()}.
     */
    public abstract ChromeApplication getChromeApplication();

    /**
    * @return A {@link CompositorViewHolder} instance.
    */
    public abstract CompositorViewHolder getCompositorViewHolder();

    /**
    * Gets the full screen manager.
    * @return The fullscreen manager, possibly null
    */
    public abstract ChromeFullscreenManager getFullscreenManager();

    /**
    * @return A {@link WindowAndroid} instance.
    */
    public abstract WindowAndroid getWindowAndroid();

    /**
     * Allows Activities that extend ChromeActivity to do additional hiding/showing of menu items.
     * @param menu Menu that is going to be shown when the menu button is pressed.
     */
    public abstract void prepareMenu(Menu menu);
}
