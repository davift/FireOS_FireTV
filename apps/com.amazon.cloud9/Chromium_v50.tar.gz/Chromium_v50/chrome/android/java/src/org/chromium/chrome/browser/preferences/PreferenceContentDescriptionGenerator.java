// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Copyright 2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

package org.chromium.chrome.browser.preferences;

import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import java.util.Arrays;
import java.util.List;

/**
 * This is an Amazon-only class that cannot be upstreamed in its current state. See BROWAPP-641.
 *
 * Contains a static method that generates content descriptions for preferences.
 */
public class PreferenceContentDescriptionGenerator {
    // Separator used to concatenate the different parts of the content description together into a
    // comma separated list. Not used to create valid sentences, and thus not localized.
    private static final String CONTENT_DESCRIPTION_SEPARATOR = ", ";

    private PreferenceContentDescriptionGenerator() {}

    /**
     * Generates a content description for a preference by combining the text of the provided views
     * and the state description.
     *
     * @param titleView The title view component of the preference layout.
     * @param summaryView The summary view component of the preference layout.
     * @param stateDescription A string that describes the state of the preference,
     *                         e.g. "Switch is on".
     *
     * @return The generated content description.
     */
    public static String generate(TextView titleView, TextView summaryView,
            CharSequence stateDescription) {
        final List<CharSequence> parts = Arrays.asList(getVisibleTextFromView(titleView),
                getVisibleTextFromView(summaryView), stateDescription);

        final StringBuilder builder = new StringBuilder();
        for (CharSequence part : parts) {
            if (!TextUtils.isEmpty(part)) {
                if (builder.length() > 0) {
                    builder.append(CONTENT_DESCRIPTION_SEPARATOR);
                }
                builder.append(part);
            }
        }

        return builder.toString();
    }

    /**
     * @return The text from the provided view, or null if the view is null or not showing.
     */
    private static CharSequence getVisibleTextFromView(TextView view) {
        if (view == null || view.getVisibility() != View.VISIBLE) return null;

        return view.getText();
    }
}
