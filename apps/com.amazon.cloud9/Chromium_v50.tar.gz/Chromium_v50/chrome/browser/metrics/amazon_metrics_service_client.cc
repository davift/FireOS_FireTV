// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "chrome/browser/metrics/amazon_metrics_service_client.h"

#include "base/command_line.h"
#include "chrome/browser/browser_process.h"
#include "chrome/browser/metrics/amazon_metrics_log_uploader.h"
#include "components/metrics/url_constants.h"

namespace {

#ifndef NDEBUG
// Configures a custom Cloud9ClientMetricCollectionService endpoint for testing
const char kCmcsEndpoint[] = "cmcs-endpoint";
#endif

} // namespace

std::string AmazonMetricsServiceClient::GetDefaultMetricsServerUrl() {
#ifndef NDEBUG
  base::CommandLine* commandLine = base::CommandLine::ForCurrentProcess();
  if (commandLine->HasSwitch(kCmcsEndpoint)) {
    std::string cmcsEndpoint = commandLine->GetSwitchValueASCII(kCmcsEndpoint);
    VLOG(1) << "Using custom CMCS endpoint: " << cmcsEndpoint;
    return cmcsEndpoint;
  }
#endif
  return metrics::kDefaultMetricsServerUrl;
}

scoped_ptr<metrics::MetricsLogUploader>
AmazonMetricsServiceClient::CreateUploader(
    const base::Callback<void(int)>& on_upload_complete) {
  return scoped_ptr<metrics::MetricsLogUploader>(
      new metrics::AmazonMetricsLogUploader(
          g_browser_process->system_request_context(),
		  GetDefaultMetricsServerUrl(),
          metrics::kDefaultMetricsMimeType,
          on_upload_complete));
}
