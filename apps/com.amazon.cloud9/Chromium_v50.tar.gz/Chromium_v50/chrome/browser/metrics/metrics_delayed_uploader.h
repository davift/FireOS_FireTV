// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef CHROME_BROWSER_METRICS_METRICS_DELAYED_UPLOADER_H_
#define CHROME_BROWSER_METRICS_METRICS_DELAYED_UPLOADER_H_

#include "net/url_request/url_fetcher.h"

namespace metrics {

class MetricsDelayedUploader {
 public:
  MetricsDelayedUploader() { }
  virtual ~MetricsDelayedUploader() { }
  virtual void UploadLog(const std::string& compressed_log_data,
      const std::string& log_hash,
      net::URLRequestContextGetter* request_context_getter,
      const std::string& server_url,
      const std::string& mime_type,
      net::URLFetcherDelegate* delegate) { }

  virtual void ClearFetcher() { }
};

}  // namespace metrics

#endif  // CHROME_BROWSER_METRICS_METRICS_DELAYED_UPLOADER_H_
