// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef CHROME_BROWSER_METRICS_AMAZON_METRICS_LOG_UPLOADER_H_
#define CHROME_BROWSER_METRICS_AMAZON_METRICS_LOG_UPLOADER_H_

#include "base/lazy_instance.h"
#include "chrome/browser/metrics/metrics_delayed_uploader.h"
#include "components/metrics/net/net_metrics_log_uploader.h"

namespace metrics {

// Implementation of MetricsLogUploader using the Chrome network stack.
class SLATIUM_EXPORT AmazonMetricsLogUploader : public NetMetricsLogUploader {
 public:
  // Constructs a NetMetricsLogUploader with the specified request context and
  // other params (see comments on MetricsLogUploader for details). The caller
  // must ensure that |request_context_getter| remains valid for the lifetime
  // of this class.
  AmazonMetricsLogUploader(
      net::URLRequestContextGetter* request_context_getter,
      const std::string server_url,
      const std::string mime_type,
      const base::Callback<void(int)>& on_upload_complete);

  void UploadLog(const std::string& compressed_log_data,
                 const std::string& log_hash) override;
  void OnURLFetchComplete(const net::URLFetcher* source) override;

 protected:
  void RunCompletionCallback(int response_code);
  virtual void RunCompletionCallbackOnUIThread(int response_code);
  void ClearDelayedUploaderFetcher();
  virtual MetricsDelayedUploader* GetDelayedUploader();

 private:
  // The request context for fetches done using the network stack.
  net::URLRequestContextGetter* const request_context_getter_;
  const std::string server_url_;
  const std::string mime_type_;

  DISALLOW_COPY_AND_ASSIGN(AmazonMetricsLogUploader);
};

// This allows embedders to register a Delayed Uploader. This can be used from
// outside of Chrome code and thus avoid a circular dependency.
// If any DelayedUploader is registered, it will be used. Otherwise no metrics
// are uploaded.
class SLATIUM_EXPORT AmazonMetricsUploaderStorage {
 public:
  ~AmazonMetricsUploaderStorage();

  static AmazonMetricsUploaderStorage* GetInstance();
  // Sets a central delayed uploader which will be used for sending metrics
  // from Chromium code. The passed uploader will be owned by
  // AmazonMetricsUploaderStorage
  void SetDelayedUploader(scoped_ptr<metrics::MetricsDelayedUploader> uploader);
  metrics::MetricsDelayedUploader* GetUploader();

 private:
  friend struct base::DefaultLazyInstanceTraits<AmazonMetricsUploaderStorage>;
  AmazonMetricsUploaderStorage();
  scoped_ptr<metrics::MetricsDelayedUploader> delayed_uploader_;
};

}  // namespace metrics

#endif  // CHROME_BROWSER_METRICS_AMAZON_METRICS_LOG_UPLOADER_H_
