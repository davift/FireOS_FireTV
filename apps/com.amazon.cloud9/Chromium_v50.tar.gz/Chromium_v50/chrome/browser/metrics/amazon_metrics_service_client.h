// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef CHROME_BROWSER_METRICS_AMAZON_METRICS_SERVICE_CLIENT_H_
#define CHROME_BROWSER_METRICS_AMAZON_METRICS_SERVICE_CLIENT_H_

#include "base/memory/scoped_ptr.h"
#include "chrome/browser/metrics/chrome_metrics_service_client.h"
#include "metrics_delayed_uploader.h"

class AmazonMetricsServiceClient
    : public ChromeMetricsServiceClient {
 public:
  explicit AmazonMetricsServiceClient(
      metrics::MetricsStateManager* state_manager)
      : ChromeMetricsServiceClient(state_manager) { }

  scoped_ptr<metrics::MetricsLogUploader> CreateUploader(
        const base::Callback<void(int)>& on_upload_complete) override;
 private:
  std::string GetDefaultMetricsServerUrl();

  DISALLOW_COPY_AND_ASSIGN(AmazonMetricsServiceClient);
};

#endif  // CHROME_BROWSER_METRICS_AMAZON_METRICS_SERVICE_CLIENT_H_
