// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "chrome/browser/metrics/amazon_metrics_log_uploader.h"

#include "base/lazy_instance.h"
#include "content/public/browser/browser_thread.h"
#include "net/base/load_flags.h"

namespace metrics {

AmazonMetricsLogUploader::AmazonMetricsLogUploader(
    net::URLRequestContextGetter* request_context_getter,
    const std::string server_url,
    const std::string mime_type,
    const base::Callback<void(int)>& on_upload_complete) :
        NetMetricsLogUploader(request_context_getter, server_url, mime_type,
             on_upload_complete),
        request_context_getter_(request_context_getter),
        server_url_(server_url),
        mime_type_(mime_type) { }

void AmazonMetricsLogUploader::UploadLog(
    const std::string& compressed_log_data, const std::string& log_hash) {
  MetricsDelayedUploader* delayed_uploader = GetDelayedUploader();
  if (delayed_uploader == nullptr) {
    LOG(WARNING)<<"Delayed Uploader is null, not sending this metric log";
    return;
  }
  delayed_uploader->UploadLog(compressed_log_data, log_hash,
      request_context_getter_, server_url_, mime_type_, this);
}

// Called on IO thread
void AmazonMetricsLogUploader::OnURLFetchComplete(const net::URLFetcher* source) {
  int response_code = source->GetResponseCode();
  if (response_code == net::URLFetcher::RESPONSE_CODE_INVALID)
    response_code = -1;
  ClearDelayedUploaderFetcher();
  RunCompletionCallbackOnUIThread(response_code);
}

void AmazonMetricsLogUploader::RunCompletionCallbackOnUIThread(
    int response_code) {
  content::BrowserThread::PostTask(
      content::BrowserThread::UI,
      FROM_HERE,
      base::Bind(&AmazonMetricsLogUploader::RunCompletionCallback,
          base::Unretained(this), response_code));
}

void AmazonMetricsLogUploader::RunCompletionCallback(int response_code) {
  on_upload_complete_.Run(response_code);
}

void AmazonMetricsLogUploader::ClearDelayedUploaderFetcher() {
  MetricsDelayedUploader* delayed_uploader = GetDelayedUploader();
  DCHECK(delayed_uploader != nullptr);
  delayed_uploader->ClearFetcher();
}

MetricsDelayedUploader* AmazonMetricsLogUploader::GetDelayedUploader() {
  return AmazonMetricsUploaderStorage::GetInstance()->GetUploader();
}

namespace {
static base::LazyInstance<AmazonMetricsUploaderStorage>
metrics_uploader_storage = LAZY_INSTANCE_INITIALIZER;
}

AmazonMetricsUploaderStorage::AmazonMetricsUploaderStorage() {
}

AmazonMetricsUploaderStorage::~AmazonMetricsUploaderStorage() {
}

AmazonMetricsUploaderStorage* AmazonMetricsUploaderStorage::GetInstance() {
  return metrics_uploader_storage.Pointer();
}

void AmazonMetricsUploaderStorage::SetDelayedUploader(
    scoped_ptr<metrics::MetricsDelayedUploader> uploader) {
  delayed_uploader_.reset(uploader.release());
}

metrics::MetricsDelayedUploader* AmazonMetricsUploaderStorage::GetUploader() {
  return delayed_uploader_.get();
}

}  // namespace metrics
