/* Copyright 2015 Amazon.com, Inc. or its affiliates. All Rights Reserved. */

#ifndef ANDROID_WEBVIEW_NATIVE_AW_WEB_CONTENTS_DELEGATE_FACTORY_H_
#define ANDROID_WEBVIEW_NATIVE_AW_WEB_CONTENTS_DELEGATE_FACTORY_H_

namespace android_webview {

class AwWebContentsDelegate;

class AwWebContentsDelegateFactory {
 public:
  virtual AwWebContentsDelegate* Create(JNIEnv* env, jobject web_contents_delegate);
};

}  // namespace android_webview

#endif  // ANDROID_WEBVIEW_NATIVE_WEB_CONTENTS_DELEGATE_FACTORY_H_
