// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

package com.android.webview.chromium;

import android.content.Context;
import android.webkit.WebView;

import com.android.webview.chromium.WebViewDelegateFactory.WebViewDelegate;

/**
 * Factory interface for instantiating custom WebViewContentsClientAdapters.
 */
public interface WebViewContentsClientAdapterFactory {

    public WebViewContentsClientAdapter create(WebView webView, Context context,
            WebViewDelegate webViewDelegate);
}
