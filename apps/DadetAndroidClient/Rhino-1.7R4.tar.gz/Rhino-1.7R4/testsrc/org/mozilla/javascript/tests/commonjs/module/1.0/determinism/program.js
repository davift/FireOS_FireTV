var test = require('test');
require('submodule/a');
test.print('DONE', 'info');
