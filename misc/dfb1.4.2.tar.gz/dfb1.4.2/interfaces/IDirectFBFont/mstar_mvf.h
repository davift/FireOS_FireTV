////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2008 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (MStar Confidential Information!�L) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _FONT_MVF_H
#define _FONT_MVF_H

#define INTERFACE




//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------

//////////////////////////////////////////////////////////////////////////
// Debug Options

//#define MVF_DEBUG

#if defined( _MSC_VER ) //defined for Visual C
#include <assert.h>
#ifndef ASSERT
#define ASSERT(x)  assert(x)
#endif //ASSERT
#endif //defined( _MSC_VER )

//////////////////////////////////////////////////////////////////////////
// Memory Management
#include <stdlib.h>
#include <string.h>
#define MVF_MALLOC(s)  malloc(s)
#define MVF_FREE(s)    free(s)
#define MVF_MEM_SET( d, s, c )  memset( d, s, c )
#define MVF_MEM_ZERO( dest, count )  memset( dest, 0, count )
#define MVF_MEM_COPY( dest, source, count )  memcpy( dest, source, count )


//////////////////////////////////////////////////////////////////////////
// Font Engine Options
#define MVF_MAX_FONT_SIZE       120
#define MVF_RENDER_POOL_SIZE  4096L   //--> Original

//NOTE: use this constant to enable QMEMORY in AEON,
//      QMEMORY size should be large or equal than MVF_RENDER_POOL_SIZE
//      remark this macro in the general case
//#define MVF_RENDER_POOL_START_ADDR 0xC0000000

//#define MVF_BITMAP_POOL_SIZE  (1*1024L) //--> Original
#define MVF_BITMAP_POOL_SIZE  (8*1024L)

//#define MVF_OUTLINE_BUFFER_SIZE (8*1024L)

#define MVF_ADDR_ALIGN(x) (((x)+3)&(~3)) //for MIPS word alignment

// small bitmap caching...
//#if   (MEMORY_MAP != MMAP_8MB) //[OBSOLETE][TEMP][TODO] BD_xxx

#define MVF_CACHE_SBITMAP_UNIT_SIZE  (36*36)
#define MVF_CACHE_SBITMAP_UNIT_COUNT 256
#define MVF_CACHE_SBITMAP_FONT_SIZE_MAX   35
#define MVR_CACHE_SBITMAP_REFRESH    1000000


// outline caching...
#define MVF_CACHE_OUTLINE_ENABLE     0
#define MVF_CACHE_OUTLINE_UNIT_COUNT 4

#define MVF_HINTING_ENABLE 1

#define MVF_BITMAP_FORMAT_MASK(x) ((x)&0x0F)
#define MVF_BITMAP_FORMAT_I8    8 // 256-level grays and 4-bytes memory alignment
#define MVF_BITMAP_FORMAT_I4    4
#define MVF_BITMAP_FORMAT_I2    2
#define MVF_BITMAP_FORMAT_I1    1 // mono render not supported yet

//NOTE: MVF_BITMAP_ALIGN_DEFAULT for default space border (suitable for TTX BIN generating),
//      otherwise will remove all left space boder (MVF_BITMAP_ALIGN_LEFT is suitable for MVF_AEON generating for LG)
#define MVF_BITMAP_ALIGN_LEFT   0x100
#define MVF_BITMAP_ALIGN_TOP    0x200
#define MVF_BITMAP_ALIGN_HCENTER 0x400

/*#if defined( _MSC_VER )
#define MVF_BITMAP_FORMAT     MVF_BITMAP_FORMAT_I8 //always 256-level for windows...
#else
#define MVF_BITMAP_FORMAT     MVF_BITMAP_FORMAT_I2
#endif*/

#define MVF_BASE_EM_SIZE 1024
//#define MVF_BASE_EM_SCALE(x,size) (((x)*(size))>>10)
#define MVF_BASE_EM_ROUND(x,size) (((x)*(size)+(MVF_BASE_EM_SIZE/2))>>10)
#define MVF_BASE_EM_FLOOR(x,size) (((x)*(size)                     )>>10)
#define MVF_BASE_EM_CEIL(x,size)  (((x)*(size)+(MVF_BASE_EM_SIZE-1))>>10)

//#define MVF_BASE_BORDER 15000

#define MVF_FOR_TRUE_TYPE_ONLY //to disable cubic curves rendering

//////////////////////////////////////////////////////////////////////////
// Contant Definitions

#define MVF_FILE_FORMAT_VERSION_7052 0x7052 
#define MVF_FILE_FORMAT_VERSION 0x7101 //2007/10 ver.1: modify this if file format is changed

#define MVF_OUTLINE_X_USE24 0 //use 24bits in X
#define MVF_OUTLINE_X_USE16 1 //use 16bits in X
#define MVF_OUTLINE_Y_USE24 0 //use 24bits in Y
#define MVF_OUTLINE_Y_USE16 2 //use 16bits in Y

#define MVF_CURVE_TAG( flag )  ( flag & 3 )
#define MVF_CURVE_TAG_ON           1
#define MVF_CURVE_TAG_CONIC        0
#define MVF_CURVE_TAG_CUBIC        2

#define MVF_HINTING_X_TOUCH_TAG  8  /* reserved for the TrueType hinter */
#define MVF_HINTING_Y_TOUCH_TAG 16  /* reserved for the TrueType hinter */
#define MVF_HINTING_TOUCH_MASK (MVF_HINTING_Y_TOUCH_TAG|MVF_HINTING_X_TOUCH_TAG)

#define MVF_PIX_MAKE( x )      ( (S16)(x) << 6 )
#define MVF_PIX_FLOOR( x )     ( (x) & ~63 )
#define MVF_PIX_ROUND( x )     MVF_PIX_FLOOR( (x) + 32 )
#define MVF_PIX_CEIL( x )      MVF_PIX_FLOOR( (x) + 63 )

#define MVF_MIN( a, b )  ( (a) < (b) ? (a) : (b) )
#define MVF_MAX( a, b )  ( (a) > (b) ? (a) : (b) )
#define MVF_ABS( a )     ( (a) < 0 ? -(a) : (a) )


//////////////////////////////////////////////////////////////////////////

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */
typedef s64 S64;
typedef s32 S32;
typedef s16 S16;
typedef s8   S8;
typedef u32 U32;
typedef u16 U16;
typedef u8   U8;

//------------------------------------------------------------------------------
// Macros
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Type and Structure Declaration
//------------------------------------------------------------------------------


typedef S32  MVF_Pos;

typedef S32 MVF_Error;

  /* GCC provides the `long long' type */
#define MVF_LONG64

  typedef struct  MVF_Vector_
  {
    MVF_Pos  x;
    MVF_Pos  y;

  } MVF_Vector;

  typedef struct  MVF_InternalOutline_
  {
    S16       n_contours;      /* number of contours in glyph        */
    S16       n_points;        /* number of points in the glyph      */

    MVF_Vector*     points;          /* the outline's points               */
    U8*       tags;            /* the points flags                   */
    S16*      contours;        /* the contour end points             */
  } MVF_InternalOutline;

  typedef struct  MVF_Outline_
  {
    S16       n_contours;      /* number of contours in glyph        */
    S16       n_points;        /* number of points in the glyph      */

    MVF_Vector*     points;          /* the outline's points               */
    U8*       tags;            /* the points flags                   */
    U16*      contours;        /* the contour end points             */

    //S16           x_shift, y_shift; // x MVF_BASE_EM_SIZE
    //U16       width, height;    // x MVF_BASE_EM_SIZE
    U16             advance_x;   // x MVF_BASE_EM_SIZE
    U16             metrics_height;   // x MVF_BASE_EM_SIZE
    S16           ascender, descender; // x MVF_BASE_EM_SIZE

#if MVF_HINTING_ENABLE
    U16       hinting_n_sizes;
    U8*       hinting_sizes;
    U8*       hinting_adv_x;
    U16      hinting_n_touch_points;
    U8*       hinting_data;
#endif

  } MVF_Outline;

  typedef struct  MVF_Bitmap_
  {
    U8*  buffer;
    U16             rows;
    U16             width;
    U16             pitch;
    S16             advance_x;

    S16             x_shift;
    S16             y_shift;
    U16             metrics_height;
    S16           ascender, descender;
  } MVF_Bitmap;

  typedef struct  MVF_InternalBitmap_
  {
    U8*  buffer;
    U16             rows;
    U16             width;
    U16             pitch;
    S16             advance_x;
  } MVF_InternalBitmap;

  typedef struct  MVF_Span_
  {
    S16           x;
    U16  len;
    U8   coverage;

  } MVF_Span;

  typedef struct  MVF_BBox_
  {
    MVF_Pos  xMin, yMin;
    MVF_Pos  xMax, yMax;

  } MVF_BBox;

////////////////////////////////////

  typedef struct MVF_GlyphRec_
  {
    U16        unicode;
    U8 * outline_data;
    U8 * kerning_data;

  } MVF_Glyph;

  typedef struct  MVF_FaceRec_
  {
    U8*  file_base;
       U8*  file_limit;

    S16         num_glyphs;
    MVF_Glyph *       glyphs;

    //2007/10/19 added new fields
    U16 file_version;
    U8*   attach_data_base;
    U8*   attach_data_limit;
    U8*   outline_buffer_start;

    U16 max_advance;
    U16 metrics_height;
    S16 ascender;
    S16 descender;

  } MVF_Face;

typedef struct MVF_HintPoint_
{
    MVF_Pos x, y, u, v, ox, oy;
    U8 touch_flags;
} MVF_HintPoint;


//------------------------------------------------------------------------------
// Extern Global Variabls
//------------------------------------------------------------------------------
// NOTE: NOT ALLOWED HERE!

//------------------------------------------------------------------------------
// Extern Functions
//------------------------------------------------------------------------------


INTERFACE MVF_Error MVF_New_Face(
                      U8 *  file_base,
                      U8 *  file_limit,  //range: [file_base, file_limit)
                      MVF_Face *        aface); //[OUT]

INTERFACE void MVF_Done_Face(
                 MVF_Face * face);

INTERFACE MVF_Error MVF_Get_Kerning( MVF_Face *     face,
                  U32     left_glyph_id,
                  U32     right_glyph_id,
                  U16     font_size,
                  MVF_Vector *    akerning ); //[OUT]

INTERFACE MVF_Error MVF_Load_Glyph( MVF_Face *   face,
                 U16   unicode,
                 MVF_Outline * outline); //[OUT]

INTERFACE MVF_Error MVF_Query_Glyph_ID( MVF_Face *   face,
                 int   unicode, 
                 int * glyph_id);               //[OUT]

INTERFACE MVF_Error MVF_Load_Glyph_By_ID( MVF_Face *   face,
                 U16   glyph_id,
                 MVF_Outline * outline); //[OUT]

INTERFACE void MVF_Done_Outline(
                 MVF_Outline * outline);

INTERFACE MVF_Error MVF_Render(
                    MVF_Face * face,
                     MVF_Outline * outline,
                     U16 font_size,
                     U32  glyph_index,
                     bool only_metrics,
                     U16 flags,
                     MVF_Bitmap * bitmap); //[OUT]


/*INTERFACE MVF_Error _MVF_Render(
                     MVF_Outline * outline,
                     MVF_Bitmap * bitmap);*/

INTERFACE void MVF_Done_Render(void);



#ifdef __cplusplus
}
#endif  /* __cplusplus */

#undef INTERFACE

#endif /* _MAPI_GFX2D_MVF_H */
