

#define FONT_MAGIC  0x466F4E74

/// Swap endian of U16 data, input:U16  output:U16
#define BYTESWAP16(x) (((x) & 0x00ff) << 8 | ((x) & 0xff00) >> 8)

/// Swap endian of U32 data, input:U32  output:U32
#define BYTESWAP32(x) \
    ((((x) & 0xff000000) >> 24) | (((x) & 0x00ff0000) >>  8) | \
     (((x) & 0x0000ff00) <<  8) | (((x) & 0x000000ff) << 24))


#define FONT_COMPRESSION_NONE               0x00
#define FONT_COMPRESSION_BOUND_RECTANGLE    0x01
#define FONT_COMPRESSION_RUN_LENGTH         0x02

#define ERR_NULL_INDEX 0xFFFF


/// Bitmap Font bin header
typedef struct
{
    uint32_t     magic;                 ///< Default is 0x466f4E74
    uint32_t     u32BPP;                 ///< Bits Per Pixel. I1: 0x01, I2: 0x02, I2 variant: 0x03 (for Saturn)
    uint32_t     u32CharNum;             ///< Character count
    uint32_t     u32Width;               ///< Width in pixels of a font
    uint32_t     u32Height;              ///< Height in pixels of a font
    uint32_t     u32Pitch;               ///< Font pitch in bytes
    uint32_t     u32Compression;         ///< 0x00 for none compression, 0x01 for bounding rectangle
    // BBox (Bounding Box) describes the smallest rectangle that encloses the shape/outline of each glyph
    uint32_t     u32BBoxOffset;          ///< Offset of BBox information
    uint32_t     u32CodemapOffset;       ///< Offset of codemap block data. Each codemap block is a tuple of(start code, end code, start index)
    uint32_t     u32CodemapBlockNum;     ///< Number of codemap block.
    uint32_t     u32CharGlyphBytes;      ///< Size of one char glyph including possible paddings for alignment
    uint32_t     u32FontGlyphOffset;     ///< Offset of glyph data
    uint32_t     u32FontGlyphBytes;      ///< Length of all the glyph data, depending on u8Compression.
} FONT_BIN_HEADER;


/// Bounding box (BBox) of a glyph
typedef struct
{
    u8  u8X0;       ///< Position of the left edge of the bounding box
    u8  u8Width;    ///< Width of the bounding box
    u8  u8Y0;       ///< Position of the top edge of the bounding box
    u8  u8Height;   ///< Height of the bounding box
} FONT_GLYPH_BBOX;


typedef struct
{
    u16  u16StartCode;      ///< Start code of this block
    u16  u16EndCode;        ///< End code of this block
    u16  u16StartIndex;     ///< Glyph start index of this block
} CHAR_CODEMAP_BLOCK;



