#!/bin/sh

FIXME_TARGET=t3
if [ "$1" != "" ]; then
    FIXME_TARGET=$1
fi

SHARED_LIB_PATH="$PHOTOSPHERE_ROOT/target/mslib"
UTOPIA_LIB_PATH="$PHOTOSPHERE_ROOT/target/mslib/utopia/$FIXME_TARGET"
DFB_NEEDED_PATH="$PHOTOSPHERE_ROOT/develop/extra"
DFB_PATH="/vendor"
PREFIX_PATH="/vendor"
echo "======= DFB needed library ======="
echo $PHOTOSPHERE_ROOT
echo $DFB_NEEDED_PATH
echo $UTOPIA_LIB_PATH
echo "=================================="

LD_LIB_PATH="-L$SHARED_LIB_PATH -L$UTOPIA_LIB_PATH -lz -lm"
CFLAGS_SETTING="-EL -I$DFB_NEEDED_PATH/libpng/include -I$DFB_NEEDED_PATH/zlib/include -I$DFB_NEEDED_PATH/jpeg/include -I$DFB_NEEDED_PATH/freetype/include/freetype2 -I$DFB_NEEDED_PATH/freetype/include"
CPPFLAGS_SETTING="-EL"
DIRECTFB_CFLAGS_SETTING="-D_REENTRANT -I$DFB_PATH/include -I$DFB_PATH/include/directfb -I$DFB_PATH/include/directfb-internal"
DIRECTFB_LIBS_SETTING="-L$DFB_PATH/lib -lfusion -ldirectfb -lpthread -ldirect"

echo "Running autoconf & automake"
autoreconf
autoconf
automake

if [ "$1" == "t2" ]; then
./configure     CC="mips-linux-gnu-gcc -EL"                             \
                CFLAGS="$CFLAGS_SETTING"                                \
                LDFLAGS="$LD_LIB_PATH"                                  \
                CPPFLAGS="$CPPFLAGS_SETTING"                            \
                FREETYPE_CFLAGS="-I$DFB_NEEDED_PATH/freetype/include"   \
                LIBS="-lrt -lpthread -lapiGFX -lapiGOP -ldrvPQ -llinux -ldrvSERFLASH"  \
                DIRECTFB_CFLAGS="$DIRECTFB_CFLAGS_SETTING"              \
                DIRECTFB_LIBS="$DIRECTFB_LIBS_SETTING"                  \
                --prefix=$PREFIX_PATH/directfb_examples                 \
                --host=mips-linux-gnu                                   \
                --build=i386-linux                                      \
                --enable-debug=yes
else
./configure     CC="mips-linux-gnu-gcc -EL"                             \
                CFLAGS="$CFLAGS_SETTING"                                \
                LDFLAGS="$LD_LIB_PATH"                                  \
                CPPFLAGS="$CPPFLAGS_SETTING"                            \
                FREETYPE_CFLAGS="-I$DFB_NEEDED_PATH/freetype/include"   \
                LIBS="-lrt -lpthread -lapiGFX -lapiGOP -llinux -ldrvSERFLASH -ldrvSYS -ldrvVE -lapiXC -lapiPNL" \
                DIRECTFB_CFLAGS="$DIRECTFB_CFLAGS_SETTING"              \
                DIRECTFB_LIBS="$DIRECTFB_LIBS_SETTING"                  \
                --prefix=$PREFIX_PATH/directfb_examples                 \
                --host=mips-linux-gnu                                   \
                --build=i386-linux                                      \
                --enable-debug=yes
fi

./fix_prefix.sh
