#!/bin/sh

#get the last change-id, and insert the info to lib
rm -rf version_info
echo "LIBCODE:[DFB]" >> version_info
echo "LIBVER:[1.4.2]" >> version_info
git log --pretty=format:"ChangeID:[%h]" -1 >> version_info
