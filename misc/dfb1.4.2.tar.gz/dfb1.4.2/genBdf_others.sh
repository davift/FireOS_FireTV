#!/bin/bash

#cat ./gfxdrivers/mstar_g2/cpptestscan.bdf  ./interfaces/IDirectFBImageProvider/cpptestscan.bdf ./interfaces/IDirectFBVideoProvider/cpptestscan.bdf  > cpptestscan.bdf
cat ./inputdrivers/mstarir/cpptestscan.bdf ./src/misc/cpptestscan.bdf > cpptestscan.bdf




