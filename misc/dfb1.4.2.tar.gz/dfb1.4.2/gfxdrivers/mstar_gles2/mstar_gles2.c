// <MStar Software>
//******************************************************************************
// MStar Software
// Copyright (c) 2010 - 2012 MStar Semiconductor, Inc. All rights reserved.
// All software, firmware and related documentation herein ("MStar Software") are
// intellectual property of MStar Semiconductor, Inc. ("MStar") and protected by
// law, including, but not limited to, copyright law and international treaties.
// Any use, modification, reproduction, retransmission, or republication of all
// or part of MStar Software is expressly prohibited, unless prior written
// permission has been granted by MStar.
//
// By accessing, browsing and/or using MStar Software, you acknowledge that you
// have read, understood, and agree, to be bound by below terms ("Terms") and to
// comply with all applicable laws and regulations:
//
// 1. MStar shall retain any and all right, ownership and interest to MStar
//    Software and any modification/derivatives thereof.
//    No right, ownership, or interest to MStar Software and any
//    modification/derivatives thereof is transferred to you under Terms.
//
// 2. You understand that MStar Software might include, incorporate or be
//    supplied together with third party`s software and the use of MStar
//    Software may require additional licenses from third parties.
//    Therefore, you hereby agree it is your sole responsibility to separately
//    obtain any and all third party right and license necessary for your use of
//    such third party`s software.
//
// 3. MStar Software and any modification/derivatives thereof shall be deemed as
//    MStar`s confidential information and you agree to keep MStar`s
//    confidential information in strictest confidence and not disclose to any
//    third party.
//
// 4. MStar Software is provided on an "AS IS" basis without warranties of any
//    kind. Any warranties are hereby expressly disclaimed by MStar, including
//    without limitation, any warranties of merchantability, non-infringement of
//    intellectual property rights, fitness for a particular purpose, error free
//    and in conformity with any international standard.  You agree to waive any
//    claim against MStar for any loss, damage, cost or expense that you may
//    incur related to your use of MStar Software.
//    In no event shall MStar be liable for any direct, indirect, incidental or
//    consequential damages, including without limitation, lost of profit or
//    revenues, lost or damage of data, and unauthorized system use.
//    You agree that this Section 4 shall still apply without being affected
//    even if MStar Software has been modified by MStar in accordance with your
//    request or instruction for your use, except otherwise agreed by both
//    parties in writing.
//
// 5. If requested, MStar may from time to time provide technical supports or
//    services in relation with MStar Software to you for your use of
//    MStar Software in conjunction with your or your customer`s product
//    ("Services").
//    You understand and agree that, except otherwise agreed by both parties in
//    writing, Services are provided on an "AS IS" basis and the warranty
//    disclaimer set forth in Section 4 above shall apply.
//
// 6. Nothing contained herein shall be construed as by implication, estoppels
//    or otherwise:
//    (a) conferring any license or right to use MStar name, trademark, service
//        mark, symbol or any other identification;
//    (b) obligating MStar or any of its affiliates to furnish any person,
//        including without limitation, you and your customers, any assistance
//        of any kind whatsoever, or any information; or
//    (c) conferring any license or right under any intellectual property right.
//
// 7. These terms shall be governed by and construed in accordance with the laws
//    of Taiwan, R.O.C., excluding its conflict of law rules.
//    Any and all dispute arising out hereof or related hereto shall be finally
//    settled by arbitration referred to the Chinese Arbitration Association,
//    Taipei in accordance with the ROC Arbitration Law and the Arbitration
//    Rules of the Association by three (3) arbitrators appointed in accordance
//    with the said Rules.
//    The place of arbitration shall be in Taipei, Taiwan and the language shall
//    be English.
//    The arbitration award shall be final and binding to both parties.
//
//******************************************************************************
// <MStar Software>

//#ifdef MSTAR_DEBUG_LAYER
#define DIRECT_ENABLE_DEBUG
//#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include <assert.h>
#include <pthread.h>
#include <directfb.h>

#define GL_GLEXT_PROTOTYPES

#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <EGL/eglplatform.h>
#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include <GLES2/gl2platform.h>
#include "mstar_natives.h"

#include "mstar_gles2.h"


#define SHARE_CONTEXT 0

#define FULL_FRAME_UPDATE 0

#if 0
#define P_INFO(x...)  printf(x)
#else
#define P_INFO(x...)
#endif

///////////////////////////////////////////////////////////////////////////////

typedef enum {
     GLES2VA_POSITIONS      = 0,
     GLES2VA_TEXCOORDS      = 1,
} GLES2VertexAttribs;

/*
 * A GLES shader program object and locations of various uniform variables.
 */
typedef struct {
     GLuint obj;          // the program object
     GLint  vColor;     // location of global RGBA color
     GLint  vColorkey;  // location of colorkey RGB color
     GLint  uSampler;   // location of 2D texture sampler
     char  *name;         // program object name for debugging
     int    v_flags;      // validation flags
} GLES2ProgramInfo;

typedef enum {
     GLES2_BLIT                             =  0,
     GLES2_NUM_PROGRAMS          = 1,
} GLES2ProgramIndex;


//////////////////////////////////////////////////////

// GLES2 shader code
const GLchar vert_src_blit[] =
        "attribute vec4 vPosition;\
         attribute vec2 aTextureCoord;\
         varying vec2 vTextureCoord;\
         void main() \
         {\
             gl_Position = vPosition;\
             vTextureCoord = vec2(aTextureCoord.s, aTextureCoord.t);\
         } ";

const GLchar frag_src_blit[] =
        "precision mediump float;\
         varying vec2 vTextureCoord;\
         uniform sampler2D uSampler;\
         void main( void )\
         {\
             vec4 color = texture2D(uSampler, vTextureCoord);\
             gl_FragColor = color;\
         }";

///////////////////////////////////////////////////////


/* global variables */


//static PFNGLEGLIMAGETARGETTEXTURE2DOESPROC glEGLImageTargetTexture2DOES = 0;
static PFNEGLGETPLATFORMDISPLAYEXTPROC eglGetPlatformDisplayEXT = 0;
static PFNEGLCREATEIMAGEKHRPROC eglCreateImageKHR = 0;
static PFNEGLDESTROYIMAGEKHRPROC eglDestroyImageKHR = 0;

static EGLDisplay eglDisplay = EGL_NO_DISPLAY;
static EGLConfig  eglConfig  = 0;
static EGLSurface eglSurface = EGL_NO_SURFACE;
static EGLContext eglContext = EGL_NO_CONTEXT;

#if SHARE_CONTEXT
static EGLContext eglShareContext = EGL_NO_CONTEXT;
#endif

EGLImageKHR eglImage_src = 0;
EGLImageKHR eglImage_dst = 0;

mst_native_buffer_t  *dst_mst_buffer;
mst_native_buffer_t  *src_mst_buffer;


static GLES2ProgramInfo     gles2_progs[GLES2_NUM_PROGRAMS];

EGLint contextAttrs[] =
{
        EGL_CONTEXT_CLIENT_VERSION, 2,
        EGL_NONE
};



/*
 * Create program shader objects for sharing across all EGL contexts.
 */

bool init_shader(GLuint prog_obj, const char *prog_src, GLenum type)
{
     char  *log;
     GLuint shader;
     GLint  status, log_length, char_count;
     GLint  sourceLen;

     sourceLen = strlen( prog_src );

     shader = glCreateShader(type);
     glShaderSource(shader, 1, (const char**)&prog_src, &sourceLen);
     glCompileShader(shader);

     glGetShaderiv(shader, GL_COMPILE_STATUS, &status);
     if (status) {
          glAttachShader(prog_obj, shader);
          glDeleteShader(shader); // mark for deletion on detach
          return true;
     }
     else {
          glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &log_length);
          log = D_MALLOC(log_length);

          glGetShaderInfoLog(shader, log_length, &char_count, log);
          D_ERROR("GLES2/Driver: shader compilation failure:\n%s\n", log);
          D_FREE(log);

          glDeleteShader(shader);
          return false;
     }
}

bool init_program(GLuint prog_obj,
             char *vert_prog_name, const char *vert_prog_src,
             char *frag_prog_name, const char *frag_prog_src,
             bool texcoords)
{
     char *log;
     GLint status, log_length, char_count;

     if (!init_shader(prog_obj, vert_prog_src, GL_VERTEX_SHADER)) {
          D_ERROR("GLES2/Driver: %s failed to compile!\n", vert_prog_name);
          return false;
     }

     if (!init_shader(prog_obj, frag_prog_src, GL_FRAGMENT_SHADER)) {
          D_ERROR("GLES2/Driver: %s failed to compile!\n", frag_prog_name);
          return false;
     }

     // Bind vertex positions to "dfbPos" vertex attribute slot.
     glBindAttribLocation(prog_obj, GLES2VA_POSITIONS, "vPosition");

     if (texcoords)
          // Bind vertex texture coords to "dfbUV" vertex attribute slot.
          glBindAttribLocation(prog_obj, GLES2VA_TEXCOORDS, "aTextureCoord");

     // Link the program object and check for errors.
     glLinkProgram(prog_obj);
     glValidateProgram(prog_obj);
     glGetProgramiv(prog_obj, GL_LINK_STATUS, &status);

     if (status) {
          // Don't need the shader objects anymore.
          GLuint  shaders[2];
          GLsizei shader_count;

          glGetAttachedShaders(prog_obj, 2, &shader_count, shaders);

          glDetachShader(prog_obj, shaders[0]);
          glDetachShader(prog_obj, shaders[1]);

          return true;
     }
     else {
          // Report errors.  Shader objects detached when program is deleted.
          glGetProgramiv(prog_obj, GL_INFO_LOG_LENGTH, &log_length);
          log = D_MALLOC(log_length);

          glGetProgramInfoLog(prog_obj, log_length, &char_count, log);
          D_ERROR("GLES2/Driver: shader program link failure:\n%s\n", log);
          D_FREE(log);

          return false;
     }

     glUseProgram( prog_obj );
}

bool gles2_init_shader_programs()
{
     int i;
     GLuint prog;
     DFBBoolean status;

     P_INFO("[%s][%s]  start!\n", __FILE__, __FUNCTION__);
     /*
      * First initialize program info slots to invalid values.
      */
     for (i = 0; i < GLES2_NUM_PROGRAMS; i++) {
          gles2_progs[i].obj          =  0;
          gles2_progs[i].vColor     = -1;
          gles2_progs[i].vColorkey  = -1;
          gles2_progs[i].uSampler   = -1;
          gles2_progs[i].name         = "";
     }

     // blit
     prog = glCreateProgram();
     status = init_program(prog, "blit_vert", vert_src_blit,
                           "blit_frag", frag_src_blit, true);
     if (status) {
          gles2_progs[GLES2_BLIT].obj = prog;
          gles2_progs[GLES2_BLIT].name = "blit";

          gles2_progs[GLES2_BLIT].uSampler = glGetUniformLocation(prog, "uSampler");

          // For now we always use texture unit 0 (GL_TEXTURE0).
          glUniform1i(gles2_progs[GLES2_BLIT].uSampler, 0);

          P_INFO("[%s][%s] -> created %s program\n", __FILE__, __FUNCTION__, gles2_progs[GLES2_BLIT].name);
     }
     else {
          printf("GLES2/Driver: blit_program init failed!\n");

          // Delete all program objects.  glDeleteProgram() will ignore object id 0.
          for (i = 0; i < GLES2_NUM_PROGRAMS; i++)
              glDeleteProgram(gles2_progs[i].obj);
          return false;
     }

     eglMakeCurrent(eglDisplay, NULL, NULL, NULL);
     P_INFO("[%s][%s] gles2_init_shader_programs done!\n", __FILE__, __FUNCTION__);

     return true;
}


static bool bindEGL(EGLImageInfo *info)
{
#if SHARE_CONTEXT
    eglShareContext = eglCreateContext(eglDisplay, eglConfig, eglContext, contextAttrs);
    if(eglShareContext == EGL_NO_CONTEXT)
    {
        printf("\033[1;31m[%s][%s] eglCreateContext ERROR ! eglGetError = %d \n", __FILE__, __FUNCTION__, eglGetError());
        return false;
    }

    P_INFO("[%s][%s][pid=%d][tid=%lld] ", __FILE__, __FUNCTION__, getpid(), pthread_self());
    P_INFO("eglDisplay: 0x%08x, eglSurface: 0x%08x, eglContext: 0x%08x, shareContext: 0x%08x\n", eglDisplay, eglSurface, eglContext, eglShareContext);

    eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglShareContext);

    P_INFO("[%s][%s] eglMakeCurrent, getError = 0x%x\n", __FILE__, __FUNCTION__, eglGetError());
#else
    P_INFO("[%s][%s][pid=%d][tid=%lld] ", __FILE__, __FUNCTION__, getpid(), pthread_self());
    P_INFO("eglDisplay: 0x%08x, eglSurface: 0x%08x, eglContext: 0x%08x\n", eglDisplay, eglSurface, eglContext);

    eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext);

    P_INFO("[%s][%s] eglMakeCurrent, getError = 0x%x\n", __FILE__, __FUNCTION__, eglGetError());
#endif

    P_INFO("[%s][%s] w=%d, h=%d, src_pitch: %d, src_phys: 0x%08x, dst_pitch: %d, dst_phys: 0x%08x\n", __FILE__, __FUNCTION__,
                   info->src.width, info->src.height, info->src.pitch, info->src.phys, info->dst.pitch, info->dst.phys);
    src_mst_buffer = D_MALLOC(sizeof(*src_mst_buffer));
    src_mst_buffer->flags    = MST_BUFFER_USE_BUS_ADDRESS;
    src_mst_buffer->format = MST_BUFFER_FORMAT_ARGB8888;
    src_mst_buffer->width   = info->src.width;
    src_mst_buffer->height  = info->src.height;
    src_mst_buffer->pitch    = info->src.pitch;
    src_mst_buffer->phys    = info->src.phys;

    dst_mst_buffer = D_MALLOC(sizeof(*dst_mst_buffer));
    dst_mst_buffer->flags    = MST_BUFFER_USE_BUS_ADDRESS;
    dst_mst_buffer->format = MST_BUFFER_FORMAT_ARGB8888;
    dst_mst_buffer->width   = info->dst.width;
    dst_mst_buffer->height  = info->dst.height;
    dst_mst_buffer->pitch    = info->dst.pitch;
    dst_mst_buffer->phys    = info->dst.phys;

    eglImage_src = eglCreateImageKHR(eglDisplay, EGL_NO_CONTEXT, EGL_NATIVE_BUFFER_MST, (EGLClientBuffer)src_mst_buffer, 0);
    if(EGL_NO_IMAGE_KHR == eglImage_src)
    {
        printf("\33[0;33;44m[%s][%s][pid=%d]\33[0m: eglCreateImageKHR Failed for eglImage_src  ! eglGetError = %d\n", __FILE__, __FUNCTION__, getpid(), eglGetError());
        return false;
    }

    eglImage_dst = eglCreateImageKHR(eglDisplay, EGL_NO_CONTEXT, EGL_NATIVE_BUFFER_MST, (EGLClientBuffer)dst_mst_buffer, 0);
    if(EGL_NO_IMAGE_KHR == eglImage_dst)
    {
        printf("\33[0;33;44m[%s][%s][pid=%d]\33[0m: eglCreateImageKHR Failed for eglImage_dst  ! eglGetError = %d\n", __FILE__, __FUNCTION__, getpid(), eglGetError());
        return false;
    }

    P_INFO("[%s][%s] eglImage_src = 0x%08x, eglImage_dst = 0x%08x\n", __FILE__, __FUNCTION__, eglImage_src, eglImage_dst);
    return true;
}

static void unbindEGL()
{
    glBindFramebuffer(GL_FRAMEBUFFER, 0);

    eglDestroyImageKHR(eglDisplay, eglImage_src);
    eglDestroyImageKHR(eglDisplay, eglImage_dst);

    if (src_mst_buffer)
        D_FREE(src_mst_buffer);

    if (dst_mst_buffer)
        D_FREE(dst_mst_buffer);

    eglMakeCurrent(eglDisplay, NULL, NULL, NULL);

#if SHARE_CONTEXT
    eglDestroyContext(eglDisplay, eglShareContext);
#endif
}

static bool createFBO()
{
    GLint status;
    GLuint fbo_dst, fboTex_dst;

    //
    glGenTextures(1, &fboTex_dst);
    glBindTexture(GL_TEXTURE_2D, fboTex_dst);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glEGLImageTargetTexture2DOES(GL_TEXTURE_2D, eglImage_dst);
    P_INFO("[%s][%s] glEGLImageTargetTexture2DOES, eglImage_dst= 0x%08x, 0x%x\n", __FILE__, __FUNCTION__, eglImage_dst, glGetError());
    //
    glGenFramebuffers(1, &fbo_dst);
    glBindFramebuffer(GL_FRAMEBUFFER, fbo_dst);

    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, fboTex_dst, 0);

    status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
    if(status != GL_FRAMEBUFFER_COMPLETE)
    {
        printf("[%s][%s]FBO bind failed!\n", __FILE__, __FUNCTION__);
        return false;
    }

    return true;
}

static void Blit_Render(GLESBlitInfo *info)
{
    GLuint TexID = 0;

#if FULL_FRAME_UPDATE

    GLfloat  vVertices[] =
    {
        -1.0f, 1.0f, 0.0f,
        -1.0f, -1.0f, 0.0f,
        1.0f, -1.0f, 0.0f,
        1.0f, 1.0f, 0.0f
    };
    GLfloat vTexCoords[] =
    {
        0.0f, 1.0f,
        0.0f, 0.0f,
        1.0f, 0.0f,
        1.0f, 1.0f,
    };

#else

    float pScale_x = 2.0f/info->eglImageInfo.dst.width;
    float pScale_y = 2.0f/info->eglImageInfo.dst.height;

    float tScale_x = 1.0f/info->eglImageInfo.src.width;
    float tScale_y = 1.0f/info->eglImageInfo.src.height;

    float x1 = info->dst_x * pScale_x - 1.0f;
    float y1 = info->dst_y * pScale_y - 1.0f;
    float x2 = (info->rect.w + info->dst_x) * pScale_x - 1.0f;
    float y2 = (info->rect.h + info->dst_y) * pScale_y - 1.0f;

    float tx1 = info->rect.x * tScale_x;
    float ty1 = info->rect.y * tScale_y;
    float tx2 = (info->rect.w + info->rect.x) * tScale_x;
    float ty2 = (info->rect.h + info->rect.y) * tScale_y;


    GLfloat  vVertices[] = {
        x1, y1, 0.0f,
        x2, y1, 0.0f,
        x2, y2, 0.0f,
        x1, y2, 0.0f
    };
    GLfloat vTexCoords[] =
    {
        tx1, ty1,
        tx2, ty1,
        tx2, ty2,
        tx1, ty2
    };

    P_INFO("[%s] TexCoords(%f, %f, %fx%f)\n", __FUNCTION__, tx1, ty1, tx2, ty2);

#endif

    glUseProgram(gles2_progs[GLES2_BLIT].obj);

    glVertexAttribPointer(GLES2VA_POSITIONS, 3, GL_FLOAT, GL_FALSE, 0, vVertices);
    glEnableVertexAttribArray(GLES2VA_POSITIONS);

    glVertexAttribPointer(GLES2VA_TEXCOORDS, 2, GL_FLOAT, GL_FALSE, 0, vTexCoords);
    glEnableVertexAttribArray(GLES2VA_TEXCOORDS);


    glGenTextures(1, &TexID);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, TexID);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glEGLImageTargetTexture2DOES(GL_TEXTURE_2D, eglImage_src);
    P_INFO("[%s][%s] glEGLImageTargetTexture2DOES, eglImage_src= 0x%08x, %d\n", __FILE__, __FUNCTION__, eglImage_src, glGetError());

    P_INFO("[%s][%s] vireport : (0, 0, %dx%d)\n", __FILE__, __FUNCTION__, info->eglImageInfo.dst.width, info->eglImageInfo.dst.height);
    glViewport(0, 0, info->eglImageInfo.dst.width, info->eglImageInfo.dst.height);
#if FULL_FRAME_UPDATE
    glScissor(0, 0, info->eglImageInfo.dst.width, info->eglImageInfo.dst.height);
#else
    glScissor(info->dst_x, info->dst_y, info->rect.w, info->rect.h);
#endif
    glEnable(GL_SCISSOR_TEST);

    // Clear the color buffer
    //glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    //glClear(GL_COLOR_BUFFER_BIT);
    //P_INFO("[%s][%s][%d] glGetError = %x\n", __FILE__, __FUNCTION__, __LINE__, glGetError());
    glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
    //P_INFO("[%s][%s][%d] glGetError = %x\n", __FILE__, __FUNCTION__, __LINE__, glGetError());
    glFinish();
    //glFlush();

    P_INFO("[%s][%s] Blit_Render done!\n", __FILE__, __FUNCTION__);

}


#ifdef VISIBILITY_HIDDEN
#pragma GCC visibility push(default)
#endif  //VISIBILITY_HIDDEN

/////////////////////////////////////////////////
bool EGL_Init(void)
{
    EGLint iMajorVersion, iMinorVersion;
    unsigned int uiRet = 0;
    bool ret = false;

    EGLint configAttribs[] =
    {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
        EGL_SURFACE_TYPE, EGL_PBUFFER_BIT,
        EGL_NONE
    };

    EGLint iConfigs = 0;

    EGLint attributes[] = {
        EGL_WIDTH, 1,
        EGL_HEIGHT, 1,
        //EGL_TEXTURE_FORMAT, EGL_TEXTURE_RGBA,
        //EGL_TEXTURE_TARGET, EGL_TEXTURE_2D,
        EGL_NONE
    };

    P_INFO("[%s][%s][pid=%d] start!\n", __FILE__, __FUNCTION__, getpid());
    if(!eglGetPlatformDisplayEXT)
    {
        eglGetPlatformDisplayEXT = (PFNEGLGETPLATFORMDISPLAYEXTPROC)eglGetProcAddress("eglGetPlatformDisplayEXT");
        assert(eglGetPlatformDisplayEXT);
    }


    eglDisplay = eglGetPlatformDisplayEXT(EGL_PLATFORM_NULL_MST, EGL_DEFAULT_DISPLAY, NULL);
    if(eglDisplay == EGL_NO_DISPLAY)
    {
        printf("\033[1;31m[%s][%s][pid=%d]: eglGetPlatformDisplayEXT ERROR = 0x%x ! \033[0m\n", __FILE__, __FUNCTION__, getpid(), eglGetError());
        return false;
    }

    uiRet = eglInitialize(eglDisplay, &iMajorVersion, &iMinorVersion);
    if(uiRet != EGL_TRUE)
    {
        printf("\033[1;31m[%s][%s][pid=%d]: eglInitialize ERROR = 0x%x ! \033[0m\n", __FILE__, __FUNCTION__, getpid(), eglGetError());
        return false;
    }

    eglBindAPI(EGL_OPENGL_ES_API);

    uiRet = eglChooseConfig(eglDisplay, configAttribs, &eglConfig, 1, &iConfigs);
    if(uiRet != EGL_TRUE)
    {
        printf("\033[1;31m[%s][%s][pid=%d]: eglChooseConfig ERROR = 0x%x !  \033[0m\n", __FILE__, __FUNCTION__, getpid(), eglGetError());
        return false;
    }

    eglSurface = eglCreatePbufferSurface(eglDisplay, eglConfig, attributes);
    if(eglSurface == EGL_NO_SURFACE)
    {
        printf("\033[1;31m[%s][%s][pid=%d]: eglCreatePbufferSurface ERROR = 0x%x! \033[0m\n", __FILE__, __FUNCTION__, getpid(), eglGetError());
        return false;
    }

    eglContext = eglCreateContext(eglDisplay, eglConfig, NULL, contextAttrs);
    if(eglContext == EGL_NO_CONTEXT)
    {
        printf("\033[1;31m[%s][%s][pid=%d]: eglCreateContext ERROR = 0x%x!  \033[0m\n", __FILE__, __FUNCTION__, getpid(), eglGetError());
        return false;
    }

    eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext);

    if(!eglCreateImageKHR)
    {
        eglCreateImageKHR = (PFNEGLCREATEIMAGEKHRPROC)eglGetProcAddress("eglCreateImageKHR");
        assert(eglCreateImageKHR);
    }

    if(!eglDestroyImageKHR)
    {
        eglDestroyImageKHR = (PFNEGLDESTROYIMAGEKHRPROC)eglGetProcAddress("eglDestroyImageKHR");
        assert(eglDestroyImageKHR);
    }
 /*if(!glEGLImageTargetTexture2DOES)     {
        glEGLImageTargetTexture2DOES = (PFNGLEGLIMAGETARGETTEXTURE2DOESPROC)eglGetProcAddress("glEGLImageTargetTexture2DOES");
        assert(glEGLImageTargetTexture2DOES);
    }*/

    P_INFO("[%s][%s][pid=%d][tid=%lld] ", __FILE__, __FUNCTION__, getpid(), pthread_self());
    P_INFO("eglDisplay: 0x%08x, eglSurface: 0x%08x, eglContext: 0x%08x\n", eglDisplay, eglSurface, eglContext);
    P_INFO("[%s][%s] done! \n", __FILE__, __FUNCTION__);

    ret = gles2_init_shader_programs();
    if (ret == false) {
         printf("[%s] GLES2: Could not create shader program objects!\n", __FUNCTION__);
         return false;
    }

    return true;
}

bool GL_blit(GLESBlitInfo *info)
{
    bool ret = true;

    P_INFO("[%s][%s] w=%d, h=%d, dx=%d, dy=%d\n", __FILE__, __FUNCTION__, info->rect.w, info->rect.h, info->dst_x, info->dst_y);

    if (bindEGL(&info->eglImageInfo)) {
        ret = createFBO();

        if (ret)
            Blit_Render(info);
        else
            printf("[DFB] GL_Blit, createFBO failed!\n");
    }
    else {
        printf("[DFB] GL_blit, bindEGL failed!\n");
        ret = false;
    }

    unbindEGL();

    return ret;
}

bool GLES_Func_init(GLESFuncs *funcs)
{
    bool ret = false;

    ret = EGL_Init();

    funcs->GLES2Blit = GL_blit;

    return ret;
}

#ifdef VISIBILITY_HIDDEN
#pragma GCC visibility pop
#endif  //VISIBILITY_HIDDEN
