#ifndef __MSTAR__SCREEN_H__
#define __MSTAR__SCREEN_H__

#include <core/screens.h>

extern ScreenFuncs mstarOPScreenFuncs;
extern ScreenFuncs mstarIP0ScreenFuncs;
extern ScreenFuncs mstarVEScreenFuncs;

#endif

