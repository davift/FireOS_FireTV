////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2008 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#include <config.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <limits.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#include <directfb.h>
#include <directfb_keynames.h>

#include "directfb.h"

#include <core/coretypes.h>

#include <core/input.h>

#include <direct/debug.h>
#include <direct/mem.h>
#include <direct/messages.h>
#include <direct/thread.h>
#include <direct/util.h>

#include <core/input_driver.h>

#include <fcntl.h>
#include <signal.h>
#ifdef HAVE_ANDROID_OS
#include <linux/sem.h>
#else
#if !USE_SIZE_OPTIMIZATION
#include <stropts.h>
#endif
#include <sys/sem.h>
#endif
#include <sys/ioctl.h>
#include <sys/ipc.h>
#include <misc/conf.h>

#include "MsTypes.h"
#include "drvIR.h"

#define MSTARIR_KEYRELEASE_PATCH

#define DEBUG_IR(x) do{(x);}while(0)

DFB_INPUT_DRIVER( mstarir )
#define DEVICE "/dev/ir"

//static DirectFBKeySymbolNames(keynames);


union semun_dfb {
 int val;
 struct semid_ds *buf;
 unsigned short *array;
} arg;

static int
driver_get_available()
{
    /* Check if we are able to read from device */
    if (access( DEVICE, R_OK ))
       return 0;

    return 1;
}

static void
driver_get_info( InputDriverInfo *info )
{
     /* fill driver info structure */
     snprintf( info->name,
               DFB_INPUT_DRIVER_INFO_NAME_LENGTH, "MSTARIR Driver" );

     snprintf( info->vendor,
               DFB_INPUT_DRIVER_INFO_VENDOR_LENGTH, "MStar Semi" );

     info->version.major = 0;
     info->version.minor = 2;
}


typedef struct {
     CoreInputDevice  *device;
     DirectThread *thread;
     int           fd;
     int           repeat_time;       
} MStarIrData;

static bool _CheckProcessExist(pid_t pid)
{
    int r;

    if (pid <= 0)
    {
        //printf("1 pid %d doesn't exist!\n", pid);
        return false;
    }
    else
    {
        r = kill(pid, 0);
        if (r == 0)
        {
            //printf("1. pid %d exist!\n", pid);
            return true;
        }
        else if (r == -1)
        {
            //printf("errno: %d\n", errno);
            //printf("strerror: %s\n", strerror(errno));

            if (errno == ESRCH)
            {
                //printf("2 pid %d doesn't exist!\n", pid);
                return false;
            }
        }
    }
    //printf("2. pid %d exist!\n", pid);
    return true;
}
#ifdef IR_CUSTOMIZE
typedef enum
{
    _IR_SHOT_P = 0x01,   /// 2'b01: only pshot edge detect for counter
    _IR_SHOT_N = 0x02,   /// 2'b10: only nshot edge detect for counter
    _IR_SHOT_PN = 0x03,  /// 2'b11/2'b00: both pshot/nshot edge detect for counter
    _IR_SHOT_INVLD,      /// Invalid for value greater than 2'b11
} IR_Shot_Sel;
void ExeKeyCode()
{
    printf("This is user keycode\n");
}
static BOOL (*UserKeyCode)(unsigned char* pu8Key,unsigned char* pu8Repeat)=0;
extern  void SetUserSoftwareDecode(bool (*func)(unsigned char* pu8Key,unsigned char* pu8Repeat));
void SetUserSoftwareDecode(bool (*func)(unsigned char* pu8Key,unsigned char* pu8Repeat))
{
    UserKeyCode = func;
}
extern DFBInputDeviceKeymapEntry*  Get_keymap_entry( CoreInputDevice *device, int code );
#endif


#ifdef MSTARIR_KEYRELEASE_PATCH
//    #define REPEAT_TIME 250      // replace with dfb_config->mst_ir_repeat_time

    static void*
    MstarIREventThread( DirectThread *thread, void *driver_data )
    {
         MStarIrData *data = (MStarIrData*) driver_data;
         /* Read keyboard data */
     long long start;
     DFBInputEvent lastEvent = {0};

    //printf("##################### MstarIREventThread $$$$$$$$$$$$$$$$$$$$$$$$$$  \n");

     while (1)
     {
            struct timeval tv =
            {
                .tv_sec = 0,
                .tv_usec = 50*1000
            };

            if(direct_thread_is_canceled(thread))
            {
                printf("thread: %s      %d   exit !\n",__FUNCTION__,__LINE__);
                direct_thread_testcancel( thread );
            }

            // process long press, and check when to dispatch release event.             
            if ( lastEvent.flags & (DIEF_REPEAT | DIEF_KEYCODE) )
            {
                bool repeat = (lastEvent.flags & DIEF_REPEAT);
                long long ir_time_diff = direct_clock_get_millis() - start;

                if( ( !repeat && ( ir_time_diff > data->repeat_time + dfb_config->mst_ir_first_time_out) ) ||
                     ( repeat && ( ir_time_diff> data->repeat_time) ) )
                {
                    D_INFO("time out!!!,end=%lld, start = %lld, diff = %lld  \n",direct_clock_get_millis(),start, ir_time_diff);
                    lastEvent.type       = DIET_KEYRELEASE;
                    lastEvent.flags &= ~DIEF_REPEAT;
                    D_INFO("~!~ DIET_KEYRELEASE type = 0x%x, flags = 0x%x , code = 0x%x \n",lastEvent.type,lastEvent.flags,lastEvent.key_code);
                    dfb_input_dispatch( data->device, &lastEvent);
                    lastEvent.type = DIET_UNKNOWN;
                    lastEvent.flags = 0;                    
                }        
            }
            
            fd_set fdset;
            FD_ZERO(&fdset);
            FD_SET(data->fd, &fdset);
            signed int ret;

            ret = select(data->fd+1, &fdset, NULL, NULL, &tv);

            if (ret > 0 && FD_ISSET(data->fd, &fdset))
            {
                unsigned int u32Data;
                unsigned char u8FantasyClass;
                read(data->fd, &u32Data, sizeof(signed int));
                u8FantasyClass=((u32Data>>28)&0xF);
                unsigned int nRept;

                DBG_INPUT_MSG("%s (%d):read_data = 0x%x\n", __FUNCTION__, __LINE__, u32Data);
                switch(u8FantasyClass)
                {
                    case 0x0f:
                    case 0x8:
                    case 0x4:
                    case 0x1: //legacy IR keypad data
                        {
#ifndef IR_CUSTOMIZE

                            DFBInputEvent evt;
                            u8 u8KeyCode;
                            u16 u16KeyCode;

                            u8KeyCode = (u32Data >> 8) & 0xFF;

                            evt.clazz = DFEC_INPUT;
                            evt.flags      = DIEF_KEYCODE;
                            evt.type       = DIET_KEYPRESS;
                            evt.key_id    = DIKI_UNKNOWN;
                            evt.key_symbol = DIKS_NULL;
                            if(u8FantasyClass == 0x4)
                            {
                                evt.key_code = u8KeyCode|(0x1<<8);
                            }
                            else if(u8FantasyClass == 0x8)
                            {
                                evt.key_code = u8KeyCode|(0x1<<9);
                            }
                            else if(u8FantasyClass == 0x1)
                            {
                                evt.key_code = u8KeyCode;
                            }
                            else if(u8FantasyClass == 0xf)
                            {
                                evt.key_code = (u32Data >> 8) & 0x0000ffff;
                            }

                            if((u32Data & 0xFF) > 0x0)
                            {
                                evt.flags |= DIEF_REPEAT;
                            }
                            else if (!dfb_config->disable_quick_press)
                            {
                                if (lastEvent.flags != 0) // if the second press is not REPEAT. this is for quick press same ir key.
                                {
                                    DFBInputEvent secEvent;
                                    
                                    secEvent.clazz          = DFEC_INPUT;
                                    secEvent.flags          = DIEF_KEYCODE;
                                    secEvent.type           = DIET_KEYRELEASE;
                                    secEvent.key_id        = DIKI_UNKNOWN;
                                    secEvent.key_symbol = DIKS_NULL;
                                    secEvent.key_code    = lastEvent.key_code;
                                    D_INFO("~!~ before the second press, DIET_KEYRELEASE type = 0x%x, flags = 0x%x , code = 0x%x \n", secEvent.type,secEvent.flags,secEvent.key_code);
                                    dfb_input_dispatch( data->device, &secEvent);
                                }
                            }
                            
                            memcpy(&lastEvent,&evt,sizeof(evt));
                            D_INFO("~!~ DIET_KEYPRESS type = 0x%x, flags = 0x%x , code = 0x%x \n",lastEvent.type,lastEvent.flags,lastEvent.key_code);
                            dfb_input_dispatch( data->device, &evt);
                            start = direct_clock_get_millis();
/* 
                                                        evt.type       = DIET_KEYRELEASE;
                                                        evt.flags &= ~DIEF_REPEAT;
                                                        dfb_input_dispatch( data->device, &evt);
*/
#endif
#ifdef IR_CUSTOMIZE
                            DFBInputEvent evt;
                            EN_KEY u8KeyCode;

                            //u8KeyCode = (u32Data >> 8) & 0xFF;
                            evt.clazz = DFEC_INPUT;
                            evt.flags      = DIEF_KEYCODE;
                            evt.type       = DIET_KEYPRESS;
                            //evt.key_code = u8KeyCode;

                            U8 u8ShotMode=0;
                            u8ShotMode = (u32Data>>24)&0x0F;

                          //  printf("shot mode = %d\n",u8ShotMode);
                            if(u8ShotMode==0)//HW decode mode
                            {
                                printf("This is HW decode mode \n");

                                u8KeyCode = (u32Data >> 8) & 0xFF;
                                if(u8FantasyClass == 0x4)
                                {
                                    evt.key_code = u8KeyCode|(0x1<<8);
                                }
                                else if(u8FantasyClass == 0x8)
                                {
                                    evt.key_code = u8KeyCode|(0x1<<9);
                                }
                                else if(u8FantasyClass == 0x1)
                                {
                                    evt.key_code = u8KeyCode;
                                }
                                D_INFO("========================================\n");
                                D_INFO("ir key code is: %d\n",u8KeyCode);
                                D_INFO("========================================\n");
                                if((u32Data & 0xFF) > 0x0)
                                {
                                    evt.flags |= DIEF_REPEAT;
                                }
                                dfb_input_dispatch( data->device, &evt);

                            }
                            else if(u8ShotMode==_IR_SHOT_N)
                            {
                                printf("This is sw decode mode \n");

                                unsigned char uRepeat=0;
                                unsigned char u8SWKeyCode=0;
                                if(UserKeyCode)
                                {
                                    printf("UserKeyCode is invoked \n");

                                    UserKeyCode(&u8SWKeyCode,&uRepeat);
                                }
                                else
                                {
                                    printf("UserKeyCode is not invoked \n");
                                    u8SWKeyCode = (u32Data >> 8) & 0xFF;
                                }
                                printf("repeat is %d\n",uRepeat);
                                if(uRepeat==1)
                                {
                                    DFBInputDeviceKeymapEntry *entry=NULL;
                                    if(u8FantasyClass == 0x4)
                                    {
                                        evt.key_code = u8KeyCode|(0x1<<8);
                                    }
                                    else if(u8FantasyClass == 0x8)
                                    {
                                        evt.key_code = u8KeyCode|(0x1<<9);
                                    }
                                    else if(u8FantasyClass == 0x1)
                                    {
                                        evt.key_code = u8KeyCode;
                                    }
                                    D_INFO("========================================\n");
                                    D_INFO("1. evt.key_code is: %d\n",evt.key_code);
                                    D_INFO("========================================\n");
                                    entry = Get_keymap_entry( data->device, evt.key_code );
                                    if(entry)
                                    {
                                        printf("Rept=%d\n",entry->nRept);
                                        if((u32Data & 0xFF) > 0x0)
                                        {
                                            evt.flags |= DIEF_REPEAT;
                                        }
                                        if(evt.flags&&entry->nRept==1)
                                        {
                                            dfb_input_dispatch( data->device, &evt);

                                        }
                                    }
                                    else
                                    {
                                        printf("entry is null\n");
                                    }
                                }
                                else
                                {
                                    if(u8FantasyClass == 0x4)
                                    {
                                        evt.key_code = u8KeyCode|(0x1<<8);
                                    }
                                    else if(u8FantasyClass == 0x8)
                                    {
                                        evt.key_code = u8KeyCode|(0x1<<9);
                                    }
                                    else if(u8FantasyClass == 0x1)
                                    {
                                        evt.key_code = u8KeyCode;
                                    }
                                    D_INFO("========================================\n");
                                    D_INFO("2. evt.key_code is: %d\n",evt.key_code);
                                    D_INFO("========================================\n");
                                    dfb_input_dispatch( data->device, &evt);

                                }
                            }
#endif
                        }
                        break;
                    case    0x2: //relative X,Y ( 0~10 bit for amount, 11 bit for direction)
                        break;
                    case    0x3: //absolute X,Y ( 0~11 bit for amount)
                        break;
                    case   0x6: //legacy IR keypad data for  another header coder(HEAD CODE  TCL)
                  {
#ifndef IR_CUSTOMIZE
                      DFBInputEvent evt;
                      u8 u8KeyCode;

                      evt.key_code  = (u32Data >> 8) & 0xFFFF;

                      evt.clazz = DFEC_INPUT;
                      evt.flags     = DIEF_KEYCODE;
                      evt.type      = DIET_KEYPRESS;
                      evt.key_id    = DIKI_UNKNOWN;
                      evt.key_symbol = DIKS_NULL;
        

                      //printf("06_Fir_dfb.key_code is %d\n",evt.key_code);

                      if((u32Data & 0xFF) > 0x0)
                      {
                          evt.flags |= DIEF_REPEAT;
                      }

                      memcpy(&lastEvent,&evt,sizeof(evt));
                      dfb_input_dispatch( data->device, &evt);
                      start = direct_clock_get_millis();


#endif
                  }
                    break;

                    default:
                        break;
                }

            }

        }
         return NULL;
    }


    #else
    static void*
    MstarIREventThread( DirectThread *thread, void *driver_data )
    {
         MStarIrData *data = (MStarIrData*) driver_data;
         /* Read keyboard data */
    
         while (1)
         {
            struct timeval tv =
            {
                .tv_sec = 0,
                .tv_usec = 100*1000
            };

            if(direct_thread_is_canceled(thread))
            {
                printf("thread: %s      %d   exit !\n",__FUNCTION__,__LINE__);
                direct_thread_testcancel( thread );            
            }

            fd_set fdset;
            FD_ZERO(&fdset);
            FD_SET(data->fd, &fdset);
            signed int ret;

            ret = select(data->fd+1, &fdset, NULL, NULL, &tv);

            if (ret > 0 && FD_ISSET(data->fd, &fdset))
            {
                unsigned int u32Data;
                unsigned char u8FantasyClass;
                read(data->fd, &u32Data, sizeof(signed int));
                u8FantasyClass=((u32Data>>28)&0xF);
                unsigned int nRept;

                switch(u8FantasyClass)
                {
                    case 0x0f:
                    case 0x8:
                    case 0x4:
                    case 0x1: //legacy IR keypad data
                        {
#ifndef IR_CUSTOMIZE
                            DFBInputEvent evt;
                            u8 u8KeyCode;
                            u16 u16KeyCode;

                            u8KeyCode = (u32Data >> 8) & 0xFF;

                            evt.clazz = DFEC_INPUT;
                            evt.flags      = DIEF_KEYCODE;
                            evt.type       = DIET_KEYPRESS;
                            evt.key_id    = DIKI_UNKNOWN;
                            evt.key_symbol = DIKS_NULL;
                            if(u8FantasyClass == 0x4)
                            {
                                evt.key_code = u8KeyCode|(0x1<<8);
                            }
                            else if(u8FantasyClass == 0x8)
                            {
                                evt.key_code = u8KeyCode|(0x1<<9);
                            }
                            else if(u8FantasyClass == 0x1)
                            {
                                evt.key_code = u8KeyCode;
                            }
                            else if(u8FantasyClass == 0xf)
                            {
                                evt.key_code = (u32Data >> 8) & 0x0000ffff;
                            }

                            if((u32Data & 0xFF) > 0x0)
                            {
                                evt.flags |= DIEF_REPEAT;
                            }

                            dfb_input_dispatch( data->device, &evt);

                             evt.type       = DIET_KEYRELEASE;
                             evt.flags &= ~DIEF_REPEAT;
                             dfb_input_dispatch( data->device, &evt);
#endif
#ifdef IR_CUSTOMIZE
                            DFBInputEvent evt;
                            EN_KEY u8KeyCode;
                            //u8KeyCode = (u32Data >> 8) & 0xFF;
                            evt.clazz = DFEC_INPUT;
                            evt.flags      = DIEF_KEYCODE;
                            evt.type       = DIET_KEYPRESS;
                            //evt.key_code = u8KeyCode;

                            U8 u8ShotMode=0;
                            u8ShotMode = (u32Data>>24)&0x0F;

                          //  printf("shot mode = %d\n",u8ShotMode);
                            if(u8ShotMode==0)//HW decode mode
                            {
                                printf("This is HW decode mode \n");

                                u8KeyCode = (u32Data >> 8) & 0xFF;
                                if(u8FantasyClass == 0x4)
                                {
                                    evt.key_code = u8KeyCode|(0x1<<8);
                                }
                                else if(u8FantasyClass == 0x8)
                                {
                                    evt.key_code = u8KeyCode|(0x1<<9);
                                }
                                else if(u8FantasyClass == 0x1)
                                {
                                    evt.key_code = u8KeyCode;
                                }
                                printf("========================================\n");
                                printf("ir key code is: %d\n",u8KeyCode);
                                printf("========================================\n");
                                if((u32Data & 0xFF) > 0x0)
                                {
                                    evt.flags |= DIEF_REPEAT;
                                }
                                dfb_input_dispatch( data->device, &evt);
                                evt.type       = DIET_KEYRELEASE;
                                dfb_input_dispatch( data->device, &evt);
                            }
                            else if(u8ShotMode==_IR_SHOT_N)
                            {
                                printf("This is sw decode mode \n");

                                unsigned char uRepeat=0;
                                unsigned char u8SWKeyCode=0;
                                if(UserKeyCode)
                                {
                                    printf("UserKeyCode is invoked \n");

                                    UserKeyCode(&u8SWKeyCode,&uRepeat);
                                }
                                else
                                {
                                    printf("UserKeyCode is not invoked \n");
                                    u8SWKeyCode = (u32Data >> 8) & 0xFF;
                                }
                                printf("repeat is %d\n",uRepeat);
                                if(uRepeat==1)
                                {
                                    DFBInputDeviceKeymapEntry *entry=NULL;
                                    if(u8FantasyClass == 0x4)
                                    {
                                        evt.key_code = u8KeyCode|(0x1<<8);
                                    }
                                    else if(u8FantasyClass == 0x8)
                                    {
                                        evt.key_code = u8KeyCode|(0x1<<9);
                                    }
                                    else if(u8FantasyClass == 0x1)
                                    {
                                        evt.key_code = u8KeyCode;
                                    }
                                    printf("========================================\n");
                                    printf("1. evt.key_code is: %d\n",evt.key_code);
                                    printf("========================================\n");
                                    entry = Get_keymap_entry( data->device, evt.key_code );
                                    if(entry)
                                    {
                                        printf("Rept=%d\n",entry->nRept);
                                        if((u32Data & 0xFF) > 0x0)
                                        {
                                            evt.flags |= DIEF_REPEAT;
                                        }
                                        if(evt.flags&&entry->nRept==1)
                                        {
                                            dfb_input_dispatch( data->device, &evt);
                                            evt.type       = DIET_KEYRELEASE;
                                            dfb_input_dispatch( data->device, &evt);
                                        }
                                    }
                                    else
                                    {
                                        printf("entry is null\n");
                                    }
                                }
                                else
                                {
                                    if(u8FantasyClass == 0x4)
                                    {
                                        evt.key_code = u8KeyCode|(0x1<<8);
                                    }
                                    else if(u8FantasyClass == 0x8)
                                    {
                                        evt.key_code = u8KeyCode|(0x1<<9);
                                    }
                                    else if(u8FantasyClass == 0x1)
                                    {
                                        evt.key_code = u8KeyCode;
                                    }
                                    printf("========================================\n");
                                    printf("2. evt.key_code is: %d\n",evt.key_code);
                                    printf("========================================\n");
                                    dfb_input_dispatch( data->device, &evt);
                                    evt.type       = DIET_KEYRELEASE;
                                    dfb_input_dispatch( data->device, &evt);
                                }
                            }
#endif
                        }
                        break;
                    case    0x2: //relative X,Y ( 0~10 bit for amount, 11 bit for direction)
                        break;
                    case    0x3: //absolute X,Y ( 0~11 bit for amount)
                        break;
                    case   0x6: //legacy IR keypad data for  another header coder(HEAD CODE  TCL)
                  {
#ifndef IR_CUSTOMIZE
                      DFBInputEvent evt;
                      u8 u8KeyCode;

                      evt.key_code  = (u32Data >> 8) & 0xFFFF;

                      evt.clazz = DFEC_INPUT;
                      evt.flags     = DIEF_KEYCODE;
                      evt.type      = DIET_KEYPRESS;
                      evt.key_id    = DIKI_UNKNOWN;
                      evt.key_symbol = DIKS_NULL;
                      //evt.key_code = u8KeyCode|0x100;
                      //evt.key_code = evt.key_code & 0x00FF;

                      printf("06_11Fir_dfb.key_code is 0x%x\n",evt.key_code);

                      if((u32Data & 0xFF) > 0x0)
                        {
                             evt.flags |= DIEF_REPEAT;
                        }

                      dfb_input_dispatch( data->device, &evt);

                      printf("06_11Fir_dfb.key_symbol is 0x%x\n",evt.key_symbol);

                      evt.type      = DIET_KEYRELEASE;
                      evt.flags &= ~DIEF_REPEAT;
                      dfb_input_dispatch( data->device, &evt);
#endif
                  }
                    break;
                    default:
                        break;
                }

            }

        }
         return NULL;
    }
#endif




static DFBResult
driver_open_device( CoreInputDevice *device,
                    unsigned int    number,
                    InputDeviceInfo *info,
                    void            **driver_data )
{

     MStarIrData *data;
     int fd;

     data = D_CALLOC(1, sizeof(MStarIrData));
     data->device = device;
     /* set private data pointer */
     *driver_data = data;

     fd = open(DEVICE, O_RDWR);
     if (fd > 0)
     {
          pid_t masterIrPid = getpid();
          int flag = 1;
          ioctl(fd, MDRV_IR_GET_MASTER_PID, &masterIrPid);

            // if master ir doesn't exist, set this as the mater ir
            if (_CheckProcessExist(masterIrPid) == false)
            {
                pid_t masterIrPid = getpid();
                // init IR
                ioctl(fd, MDRV_IR_INIT);
                ioctl(fd, MDRV_IR_SET_MASTER_PID, &masterIrPid);
            }
            ioctl(fd, MDRV_IR_ENABLE_IR, &flag);
   }
   else
   {
         DEBUG_IR(printf("Fail to open IR Kernal Module\n"));
         D_FREE(data);
         return DFB_FAILURE;
   }
   data->fd = fd;
   data->repeat_time= dfb_config->mst_ir_repeat_time;

     /* fill driver info structure */
     snprintf( info->desc.name,
               DFB_INPUT_DEVICE_DESC_NAME_LENGTH, "MSTARIR Device" );

     snprintf( info->desc.vendor,
               DFB_INPUT_DEVICE_DESC_VENDOR_LENGTH, "MStar Semi" );

     info->prefered_id = DIDID_MSTARIR;

     info->desc.type   = DIDTF_REMOTE;
     info->desc.caps   = DICAPS_KEYS;

     info->desc.min_keycode = 0;
     info->desc.max_keycode = dfb_config->mst_ir_max_keycode;  //0x7FFF;

     /* start input thread */

     data->thread = direct_thread_create( DTT_INPUT, MstarIREventThread, data, "MStar IR" );


     return DFB_OK;
}

/*
 * Fetch one entry from the device's keymap if supported.
 */
static DFBResult
driver_get_keymap_entry( CoreInputDevice           *device,
                         void                      *driver_data,
                         DFBInputDeviceKeymapEntry *entry )
{
    return DFB_UNSUPPORTED;
}


static void
driver_close_device( void *driver_data )
{
     MStarIrData *data = (MStarIrData*) driver_data;

     direct_thread_cancel( data->thread );

     direct_thread_join( data->thread );

     direct_thread_destroy( data->thread );

     /* close socket */
     close( data->fd );


     /* free private data */
    D_FREE( data );
}

static DFBResult
driver_device_ioctl( CoreInputDevice              *device,
                      void                         *driver_data,
                     InputDeviceIoctlData *param)
{
     MStarIrData *data = (MStarIrData*) driver_data;


     if(MDRV_DFB_IOC_MAGIC!= _IOC_TYPE(param->request))
         return DFB_INVARG;

     switch(param->request)
     {
       case DFB_DEV_IOC_SET_MSTARIR_REPEAT_TIME:
          if(((int)param->param[0])<=0)
              return DFB_INVARG;
          data->repeat_time= ((int)param->param[0]);
          printf("[DFB] Mstarir Set repeat time:%d (ms)", data->repeat_time);
          break;
          
       case DFB_DEV_IOC_GET_MSTARIR_REPEAT_TIME:
          memset(param->param, 0, sizeof(param->param));
          param->param[0] = data->repeat_time;
          printf("[DFB] Mstarir Get repeat time:%d (ms)", data->repeat_time);
          break;
        
       default:
          return DFB_UNSUPPORTED;
     }

     return DFB_OK;
}
