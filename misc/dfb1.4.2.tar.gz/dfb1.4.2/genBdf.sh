#!/bin/bash

#cat ./gfxdrivers/mstar_g2/cpptestscan.bdf  ./interfaces/IDirectFBImageProvider/cpptestscan.bdf ./interfaces/IDirectFBVideoProvider/cpptestscan.bdf  ./lib/direct/cpptestscan.bdf  > cpptestscan.bdf
cat ./gfxdrivers/mstar_g2/cpptestscan.bdf  ./interfaces/IDirectFBImageProvider/cpptestscan.bdf ./interfaces/IDirectFBVideoProvider/cpptestscan.bdf  > cpptestscan.bdf





