/*
   (c) Copyright 2001-2009  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrjälä <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.
*/

#include <config.h>

#include <pthread.h>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <string.h>

#include <directfb.h>
#include <directfb_version.h>

#include <misc/conf.h>
#include <misc/util.h>

#include <core/core.h>
#include <core/coredefs.h>
#include <core/coretypes.h>

#include <core/input.h>
#include <core/layer_context.h>
#include <core/layer_control.h>
#include <core/layers.h>
#include <core/state.h>
#include <core/gfxcard.h>
#include <core/surface.h>
#include <core/windows.h>
#include <core/windowstack.h>
#include <core/wm.h>

#include <gfx/convert.h>

#include <direct/conf.h>
#include <direct/direct.h>
#include <direct/interface.h>
#include <direct/log.h>
#include <direct/mem.h>
#include <direct/messages.h>
#include <direct/util.h>

#include <display/idirectfbsurface.h>

#include <idirectfb.h>

#if USE_DYNAMIC_LINK
#else
#include "DFBInfo.h"
#endif

//DFBInfo
#include <dlfcn.h>
#define DFBINFO_PATH    "/config/libdfbinfo.so"
typedef bool (*SetKEYPADCfg_Func)();
typedef bool (*SetExtDFBRcCfg_Func)();

//libapiGOP
#if (!ARCH_X86 && !ARCH_X86_64)
#include <MsCommon.h>
#include  <apiGOP.h>

#define LIBAPIGOP_PATH  "libapiGOP.so"
#define LEAST_SUPPORT_GOP_VERSION   81
typedef E_GOP_API_Result (*GetChipCaps_Func)(EN_GOP_CAPS,u8*,u32);

#endif


#ifdef VISIBILITY_HIDDEN
#pragma GCC visibility push(default)
#endif  //VISIBILITY_HIDDEN


static void*s_dfbinfo_hanle = NULL;


#if USE_DYNAMIC_LINK
static bool
DirectFBDoDFBInfo_SetKEYPADCfg()
{
    SetKEYPADCfg_Func func = NULL;
    bool ret = false;
    if(NULL == s_dfbinfo_hanle)
        s_dfbinfo_hanle = dlopen(DFBINFO_PATH, RTLD_LAZY);;

    if(!s_dfbinfo_hanle)
    {
        printf("Note:dlopen %s fail !!! If you do not use SN, Please Ignore it\n",DFBINFO_PATH);
        printf("Note:dlerror() : %s,  If you do not use SN, Please Ignore it\n", dlerror());
        return ret;
    }

    func = (SetKEYPADCfg_Func)dlsym(s_dfbinfo_hanle, "SetKEYPADCfg");
    if(func)
        ret = func();
    else
        printf("Note: Get func SetKEYPADCfg fail! If you do not use SN, Please Ignore it\n");

    if(ret == false)
        printf("Note: DirectFBDoDFBInfo_SetKEYPADCfg fail !!!  If you do not use SN, Please Ignore it\n");

    //!!! don't close it
//    dlclose(handle);

    return ret;
}
#else
static bool
DirectFBDoDFBInfo_SetKEYPADCfg()
{
    bool ret = false;

    ret = SetKEYPADCfg();

    return ret;
}

#endif


#if USE_DYNAMIC_LINK
#if (!ARCH_X86 && !ARCH_X86_64)
static bool
DirectFBDoDFBInfo_SetDFBRcCfg()
{

    SetExtDFBRcCfg_Func func = NULL;
    bool ret = false;

    if(NULL == s_dfbinfo_hanle)
        s_dfbinfo_hanle = dlopen(DFBINFO_PATH, RTLD_LAZY);;

    if(!s_dfbinfo_hanle)
    {
        printf("Note:dlopen %s fail !!! If you do not use SN, Please Ignore it\n",DFBINFO_PATH);
        printf("Note:dlerror() : %s,  If you do not use SN, Please Ignore it\n", dlerror());
        return ret;
    }

    func = (SetExtDFBRcCfg_Func)dlsym(s_dfbinfo_hanle, "SetExtDFBRcCfg");
    if(func)
        ret = func();
    else
        printf("Note: Get func SetExtDFBRcCfg fail! If you do not use SN, Please Ignore it\n");

    if(ret == false)
        printf("Note: DirectFBDoDFBInfo_SetDFBRcCfg fail !!!  If you do not use SN, Please Ignore it\n");

    return ret;
}
#endif
#else
static bool
DirectFBDoDFBInfo_SetDFBRcCfg()
{
    bool ret = false;

    ret = SetExtDFBRcCfg();

    return ret;
}
#endif


IDirectFB *idirectfb_singleton = NULL;
pthread_mutex_t  g_dfb_lock_counter_mutex= PTHREAD_MUTEX_INITIALIZER;
unsigned volatile int g_dfb_lock_flag = 0;
static DFBResult CreateRemote( const char *host, int session, IDirectFB **ret_interface );

/*
 * Version checking
 */
const unsigned int directfb_major_version = DIRECTFB_MAJOR_VERSION;
const unsigned int directfb_minor_version = DIRECTFB_MINOR_VERSION;
const unsigned int directfb_micro_version = DIRECTFB_MICRO_VERSION;
const unsigned int directfb_binary_age    = DIRECTFB_BINARY_AGE;
const unsigned int directfb_interface_age = DIRECTFB_INTERFACE_AGE;

#if !USE_SIZE_OPTIMIZATION
const char *
DirectFBCheckVersion( unsigned int required_major,
                      unsigned int required_minor,
                      unsigned int required_micro )
{
     if (required_major > DIRECTFB_MAJOR_VERSION)
          return "DirectFB version too old (major mismatch)";
     if (required_major < DIRECTFB_MAJOR_VERSION)
          return "DirectFB version too new (major mismatch)";
     if (required_minor > DIRECTFB_MINOR_VERSION)
          return "DirectFB version too old (minor mismatch)";
     if (required_minor < DIRECTFB_MINOR_VERSION)
          return "DirectFB version too new (minor mismatch)";
     if (required_micro < DIRECTFB_MICRO_VERSION - DIRECTFB_BINARY_AGE)
          return "DirectFB version too new (micro mismatch)";
     if (required_micro > DIRECTFB_MICRO_VERSION)
          return "DirectFB version too old (micro mismatch)";

     return NULL;
}

const char *
DirectFBUsageString( void )
{
     return dfb_config_usage();
}
#endif


#if (!ARCH_X86 && !ARCH_X86_64)
DFBResult
DirectFBGOPSetForceWrite(bool benable)
{
  
    E_GOP_API_Result ret = GOP_API_FAIL;

    DFB_BOOT_GETTIME( DF_BOOT_MSOS_INIT, DF_MEASURE_START, DF_BOOT_LV1);

    if (benable)
        MsOS_Init();

    DFB_BOOT_GETTIME( DF_BOOT_MSOS_INIT, DF_MEASURE_END, DF_BOOT_LV1);
 
    MApi_GOP_GWIN_SetForceWrite(benable);

    return DFB_OK;
 } 
#else

DFBResult
DirectFBGOPSetForceWrite(bool benable)
{
    return DFB_OK;
} 
 
 
#endif


#define MSTAR_MULTI_GOP_SUPPORT TRUE
#define MSTAR_MAX_OUTPUT_LAYER_COUNT 6
DFBResult
DirectFBInit( int *argc, char *(*argv[]) )
{    
#ifdef DFB_MEASURE_BOOT_TIME
     dfb_boot_initENV();
#endif


     DFB_BOOT_GETTIME( DF_BOOT_DIRECTFBINIT, DF_MEASURE_START, DF_BOOT_LV1);

     DFBResult ret;

     printf("==========================================\n");
     printf("DFB library build @ ");
     printf(BUILDTIME);
     printf("\n\n");
     printf("===========================================\n");

     DFB_BOOT_GETTIME( DF_BOOT_CONFIG_INIT, DF_MEASURE_START, DF_BOOT_LV2);

     ret = dfb_config_init( argc, argv );
     
     DFB_BOOT_GETTIME( DF_BOOT_CONFIG_INIT, DF_MEASURE_END, DF_BOOT_LV2);

     DFB_CHECK_POINT("dfb_config_init done");

     if (ret)
          return ret;


     DFB_BOOT_GETTIME( DF_BOOT_SETKEYPADCFG, DF_MEASURE_START, DF_BOOT_LV2);

#if (!ARCH_X86 && !ARCH_X86_64)     //X86 doesn't support this
     if (dfb_config->mst_disable_dfbinfo == false)
     {
         if(!DirectFBDoDFBInfo_SetKEYPADCfg())
         {
            printf("Note: DFBCreate: DirectFBDoDFBInfo_SetKEYPADCfg fail!  If you do not use SN, Please Ignore it\n");
             //return DFB_FAILURE;
         }
     }
#endif

     DFB_BOOT_GETTIME( DF_BOOT_SETKEYPADCFG, DF_MEASURE_END, DF_BOOT_LV2);

     DFB_CHECK_POINT("DirectFBDoDFBInfo_SetKEYPADCfg done");


     DFB_BOOT_GETTIME( DF_BOOT_DIRECTFBINIT, DF_MEASURE_END, DF_BOOT_LV1);

     DFB_CHECK_POINT("DirectFBInit done");

     return DFB_OK;
}



DFBResult
DirectFBSetOption( const char *name, const char *value )
{
     DFBResult ret;

     if (dfb_config == NULL) {
          D_ERROR( "DirectFBSetOption: DirectFBInit has to be "
                   "called before DirectFBSetOption!\n" );
          return DFB_INIT;
     }



     if (!name)
          return DFB_INVARG;

     ret = dfb_config_set( name, value );
     if (ret)
          return ret;

      if (idirectfb_singleton) {
      D_ERROR( "DirectFBSetOption: DirectFBSetOption has to be "
               "called before DirectFBCreate!\n" );
      return DFB_INIT;
      
     }

     return DFB_OK;
}


/*
Afford one interface for the AP to get the miu cpu offset
*/

DFBResult
DirectFBGetMIUCPUOffset(DFBMIUIdentifier identifier, unsigned long * puloffset)
{

     if (dfb_config == NULL)
     {
          D_ERROR( "DirectFBSetOption: DirectFBInit has to be "
                   "called before DirectFBSetOption!\n" );
          return DFB_INIT;
     }

    if((identifier >= DFB_MIUMAX)||(!puloffset))
    {
        return DFB_INVARG;
    }

    if(DFB_MIU0 == identifier)
    {
       *puloffset = dfb_config->mst_miu0_cpu_offset;
    }
    else if(DFB_MIU1 == identifier)
    {
       *puloffset = dfb_config->mst_miu1_cpu_offset;
    }
    else
    {
         return DFB_INVARG;
    }

    return DFB_OK;
}

/*
Afford one interface for the AP to get the miu hal offset
*/
DFBResult
DirectFBGetMIUHALOffset(DFBMIUIdentifier identifier, unsigned long * puloffset)
{

     if (dfb_config == NULL)
     {
          D_ERROR( "DirectFBSetOption: DirectFBInit has to be "
                   "called before DirectFBSetOption!\n" );
          return DFB_INIT;
     }

    if((identifier >= DFB_MIUMAX)||(!puloffset))
    {
        return DFB_INVARG;
    }

    if(DFB_MIU0 == identifier)
    {
       *puloffset = dfb_config->mst_miu0_hal_offset;
    }
    else if(DFB_MIU1 == identifier)
    {
       *puloffset = dfb_config->mst_miu1_hal_offset;
    }
    else
    {
        return DFB_INVARG;
    }

    return DFB_OK;
}



/*
    Afford one interface to get the Mirror Mode
*/

DFBResult
DirectFBGetMirrorInfo(DFBMirrorInfo *pstdfbMirroInfo)
{

     if (dfb_config == NULL)
     {
          D_ERROR( "DirectFBSetOption: DirectFBInit has to be "
                   "called before DirectFBSetOption!\n" );
          return DFB_INIT;
     }

     pstdfbMirroInfo->DFB_HMirrorEnable = false;
     pstdfbMirroInfo->DFB_VMirrorEnable = false;
     if(dfb_config->mst_GOP_HMirror > 0)
        pstdfbMirroInfo->DFB_HMirrorEnable = true;

     if(dfb_config->mst_GOP_VMirror > 0)
        pstdfbMirroInfo->DFB_VMirrorEnable = true;

    return DFB_OK;
}

static void DirectfbInitThread(void)
{
    /* BUGFIX for Mantis 0593809 to avoid OOM problem.
       Make the Master Process to have the most hightest priority to release memory.
    */ 
    sleep(25);
    
    nice(-20);
}

#if !USE_SIZE_OPTIMIZATION
const char* get_process_name_by_pid(const int pid)
{
    char* name = (char*)calloc(1024,sizeof(char));
    if(name){
        sprintf(name, "/proc/%d/cmdline",pid);
        FILE* f = fopen(name,"r");
        if(f){
            size_t size;
            size = fread(name, sizeof(char), 1024, f);

            if(size>0){
                if('\n'==name[size-1])
                    name[size-1]='\0';
            }
            fclose(f);
        }
    }
    return name;
}
#endif

/*
 * Programs have to call this to get the super interface
 * which is needed to access other functions
 */
DFBResult
DirectFBCreate( IDirectFB **interface )
{
     DFB_CHECK_POINT("DirectFBCreate start");
    
     DFB_BOOT_GETTIME( DF_BOOT_DIRECTFBCREATE, DF_MEASURE_START, DF_BOOT_LV1);

     DFBResult  ret = DFB_OK;
     IDirectFB *dfb = NULL;//Fix converity END
     CoreDFB   *core_dfb = NULL;//Fix converity END

     if (!dfb_config) {
          /*  don't use D_ERROR() here, it uses dfb_config  */
          direct_log_printf( NULL, "(!) DirectFBCreate: DirectFBInit "
                             "has to be called before DirectFBCreate!\n" );
          return DFB_INIT;
     }

     if (!interface)
          return DFB_INVARG;

     if (idirectfb_singleton) {
          idirectfb_singleton->AddRef( idirectfb_singleton );
          *interface = idirectfb_singleton;
          return DFB_OK;
     }

     DFB_BOOT_GETTIME( DF_BOOT_CONFIG_SET, DF_MEASURE_START, DF_BOOT_LV2);

#if USE_DYNAMIC_LINK
#if (!ARCH_X86 && !ARCH_X86_64)     //X86 doesn't support this
     if (dfb_config->mst_disable_dfbinfo == false)
     {
         if(!DirectFBDoDFBInfo_SetDFBRcCfg())
         {
            printf("Note:DFBCreate: DirectFBDoDFBInfo_SetDFBRcCfg fail! If you do not use SN, Please Ignore it \n");
            //return DFB_FAILURE;
         }
     }
#endif  // end of (!ARCH_X86 && !ARCH_X86_64)
#else
     if (dfb_config->mst_disable_dfbinfo == false)
     {
         // wait dfbinfo.a   downsize

         if(!SetExtDFBRcCfg())
         {
            printf("Note:DFBCreate: DirectFBDoDFBInfo_SetDFBRcCfg fail! If you do not use SN, Please Ignore it \n");
            //return DFB_FAILURE;
         }
     }
#endif

     DFB_BOOT_GETTIME( DF_BOOT_CONFIG_SET, DF_MEASURE_END, DF_BOOT_LV2);

     DFB_CHECK_POINT("DirectFBDoDFBInfo_SetDFBRcCfg done");

     DFB_BOOT_GETTIME( DF_BOOT_DIRECT_INIT, DF_MEASURE_START, DF_BOOT_LV2);

     direct_initialize();

     DFB_BOOT_GETTIME( DF_BOOT_DIRECT_INIT, DF_MEASURE_END, DF_BOOT_LV2);

     DFB_CHECK_POINT("direct_initialize done");

     if ( !(direct_config->quiet & DMT_BANNER) && dfb_config->banner) {
          direct_log_printf( NULL,
                             "\n"
                             "   ~~~~~~~~~~~~~~~~~~~~~~~~~~| DirectFB " DIRECTFB_VERSION " |~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
                             "        (c) 2001-2009  The world wide DirectFB Open Source Community\n"
                             "        (c) 2000-2004  Convergence (integrated media) GmbH\n"
                             "      ----------------------------------------------------------------\n"
                             "\n" );
     }

     if (dfb_config->remote.host)
          return CreateRemote( dfb_config->remote.host, dfb_config->remote.session, interface );


     DFB_BOOT_GETTIME( DF_BOOT_CORE_CREATE, DF_MEASURE_START, DF_BOOT_LV2);

     ret = dfb_core_create( &core_dfb );

     DFB_BOOT_GETTIME( DF_BOOT_CORE_CREATE, DF_MEASURE_END, DF_BOOT_LV2);

     DFB_CHECK_POINT("dfb_core_create done");


     if (ret)
          return ret;

     DIRECT_ALLOCATE_INTERFACE( dfb, IDirectFB );


     DFB_BOOT_GETTIME( DF_BOOT_IDIRECTFB_CONSTRUCT, DF_MEASURE_START, DF_BOOT_LV2);

     ret = IDirectFB_Construct( dfb, core_dfb );

     DFB_BOOT_GETTIME( DF_BOOT_IDIRECTFB_CONSTRUCT, DF_MEASURE_END, DF_BOOT_LV2);

     DFB_CHECK_POINT("IDirectFB_Construct done");

     
     if (ret) {
          dfb_core_destroy( core_dfb, false );
          return ret;
     }

     if (dfb_core_is_master( core_dfb )) {
         
        if (dfb_config->mst_disable_master_pri_high == false)
        {
                pthread_t id;
                int ret;

                ret = pthread_create(&id, NULL, (void *) DirectfbInitThread, NULL);

                if( 0 != ret)
                {
                    D_WARN(ret, "Create pthread fail!\n");
                }
        } 

          /* not fatal */
          ret = dfb_wm_post_init( core_dfb );
          if (ret)
               D_DERROR( ret, "DirectFBCreate: Post initialization of WM failed!\n" );

          dfb_core_activate( core_dfb );

     }

     *interface = idirectfb_singleton = dfb;


    DFB_BOOT_GETTIME( DF_BOOT_DIRECTFBCREATE, DF_MEASURE_END, DF_BOOT_LV1);

    DFB_CHECK_POINT("DirectfbCreate done");

#if DFB_MEASURE_BOOT_TIME
    dfb_boot_printTimeInfo();
#endif

     return DFB_OK;
}

DFBResult
DirectFBSetGOPDst(DFBDisplayLayerID         id, DFBDisplayLayerGOPDST gop_dst )
{
    return dfb_layer_Set_GopDst(id, gop_dst);
}

DFBDisplayLayerGOPDST
DirectFBGetGOPDst(DFBDisplayLayerID         id)
{
    return dfb_layer_Get_GopDst(id);
}

u8
DirectFBGetGOPIndex(DFBDisplayLayerID     id)
{
    return dfb_layer_Get_GopIndex(id);
}

DFBResult
DirectFBSetBootLogoPatch(DFBDisplayLayerID id, int miusel )
{
    return dfb_layer_Set_Boot_Logo_Patch(id, miusel);
}


DFBResult
DirectFBError( const char *msg, DFBResult error )
{
     if (msg)
          direct_log_printf( NULL, "(#) DirectFBError [%s]: %s\n", msg,
                             DirectFBErrorString( error ) );
     else
          direct_log_printf( NULL, "(#) DirectFBError: %s\n",
                             DirectFBErrorString( error ) );

     return error;
}

const char *
DirectFBErrorString( DFBResult error )
{
     if (D_RESULT_TYPE_IS( error, 'D','F','B' )) {
          switch (error) {
               case DFB_NOVIDEOMEMORY:
                    return "Out of video memory!";
               case DFB_MISSINGFONT:
                    return "No font has been set!";
               case DFB_MISSINGIMAGE:
                    return "No image has been set!";
               default:
                    return "UKNOWN DIRECTFB RESULT!";
          }
     }

     return DirectResultString( error );
}

#if !USE_SIZE_OPTIMIZATION
DFBResult
DirectFBErrorFatal( const char *msg, DFBResult error )
{
     DirectFBError( msg, error );

     //if (idirectfb_singleton)
          //IDirectFB_Destruct( idirectfb_singleton );

     exit( error );
}
#endif

/**************************************************************************************************/

static DFBResult
CreateRemote( const char *host, int session, IDirectFB **ret_interface )
{
     DFBResult             ret;
     DirectInterfaceFuncs *funcs = NULL;
     void                 *interface;

     D_ASSERT( host != NULL );
     D_ASSERT( ret_interface != NULL );

     ret = DirectGetInterface( &funcs, "IDirectFB", "Requestor", NULL, NULL );
     if (ret)
          return ret;

     ret = funcs->Allocate( &interface );
     if (ret)
          return ret;

     ret = funcs->Construct( interface, host, session );
     if (ret)
          return ret;

     *ret_interface = idirectfb_singleton = interface;

     return DFB_OK;
}


#ifdef VISIBILITY_HIDDEN
#pragma GCC visibility pop
#endif  //VISIBILITY_HIDDEN

