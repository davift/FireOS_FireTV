#!/bin/sh

#Please modify your SUPERNOVA_ROOT and DFB_PATH
DFB_PATH="$DFB_PATH"
SUPERNOVA_ROOT="$SUPERNOVA_ROOT"
MST_PREFIX=/vendor
export DESTDIR=`pwd`/output

function build()
{
test -z $DFB_PATH && echo "the DFB_PATH must be set!!" && exit 0
test -z $SUPERNOVA_ROOT && echo "the SUPERNOVA_ROOT must be set!!" && exit 0

CHIP=munich
#if [ "$1" != "" ]; then
#    CHIP=munich
#fi

SHARED_LIB_PATH="$SUPERNOVA_ROOT/target/$PROJ_MODE.$CHIP/mslib"
DFB_NEEDED_PATH="$SUPERNOVA_ROOT/develop/include"
UTOPIA_LIB_PATH="$SUPERNOVA_ROOT/target/$PROJ_MODE.$CHIP/mslib/utopia/"
UTOPIA_INCLUDE_PATH="$SUPERNOVA_ROOT/develop/include/utopia/$CHIP"

echo "======= DFB needed library ======="
echo $SUPERNOVA_ROOT
echo $SHARED_LIB_PATH
echo $DFB_NEEDED_PATH
echo $UTOPIA_LIB_PATH
echo $UTOPIA_INCLUDE_PATH
echo "=================================="

LD_LIB_PATH="-L$SHARED_LIB_PATH -L$UTOPIA_LIB_PATH -lz -lm"
CFLAGS_SETTING="-DVISIBILITY_HIDDEN -DMSOS_PROCESS_SAFT_MUTEX -mlittle-endian  -march=armv7-a -mcpu=cortex-a9 -mfpu=neon  -mfloat-abi=softfp -Wall -Wpointer-arith -Wstrict-prototypes -Winline -Wundef -fno-strict-aliasing -fno-optimize-sibling-calls -fno-exceptions -ffunction-sections -fdata-sections -O2 -fno-peephole2 -pthread -I$DFB_NEEDED_PATH/png -I$DFB_NEEDED_PATH/zlib -I$DFB_NEEDED_PATH/jpeg -I$DFB_NEEDED_PATH/freetype/freetype2 -I$DFB_NEEDED_PATH/freetype -I$UTOPIA_INCLUDE_PATH -I$DFB_PATH -DMSOS_TYPE_LINUX"
CPPFLAGS_SETTING=" -DMSOS_PROCESS_SAFT_MUTEX -mlittle-endian  -march=armv7-a -mcpu=cortex-a9 -mfpu=neon  -mfloat-abi=softfp -Wall -Wpointer-arith -Wstrict-prototypes -Winline -Wundef -fno-strict-aliasing -fno-optimize-sibling-calls -fno-exceptions -ffunction-sections -fdata-sections -O2 -fno-peephole2 -pthread "

if [ -f $UTOPIA_INCLUDE_PATH/UFO.h ]; then
    CFLAGS_SETTING+=" -DHAVE_UFO_H";
fi

echo $CFLAGS_SETTING | grep VISIBILITY_HIDDEN

if [ $? == 0 ];  then
    _CC_="arm-none-linux-gnueabi-gcc -mlittle-endian -fvisibility=hidden"
else
    _CC_="arm-none-linux-gnueabi-gcc -mlittle-endian"
fi


# **********************************************
# Reference Libs
# **********************************************
if [ "$CHIP" == "t2" ]; then
    MSTAR_LIB=" -lrt -lpthread -lapiGFX -lapiGOP -ldrvPQ -llinux -ldrvSERFLASH"
else
    MSTAR_LIB=" -lrt -lpthread -ldrvMVOP -lapiGFX -lapiGOP -llinux  -ldrvVE -lapiXC -lapiPNL -ldrvWDT -ldrvSAR -lapiSWI2C -ldrvGPIO -ldrvCPU "
fi
HW_DECODEJPEG_LIBS=" -lapiVDEC -ldrvIPAUTH -lapiJPEG "
HW_DECODEGIF_LIBS="-lapiGPD"

echo "Running autoconf & automake"
autoreconf
autoconf
automake

./configure     CC="$_CC_" \
                LD="arm-none-linux-gnueabi-ld -EL"\
                CFLAGS="$CFLAGS_SETTING" \
                LDFLAGS="-Wl,-rpath,/mslib -Wl,-rpath,/lib $LD_LIB_PATH" \
                CPPFLAGS="$CPPFLAGS_SETTING" \
                FREETYPE_CFLAGS="-I$DFB_NEEDED_PATH/freetype " \
                FREETYPE_LIBS="-lfreetype -lz" \
                LIBS="$MSTAR_LIB $HW_DECODEJPEG_LIBS $HW_DECODEGIF_LIBS " \
                --prefix=$MST_PREFIX \
                --sysconfdir=/config \
                --host=arm-none-linux-gnueabi \
                --build=i386-linux \
                --enable-jpeg \
                --enable-zlib \
                --enable-png \
                --enable-gif \
                --enable-gopc \
                --enable-vec \
                --enable-freetype \
                --disable-debug \
                --disable-profiling \
                --disable-unique \
                --with-gfxdrivers=mstargfx,mstargfx_g2 \
                --with-inputdrivers=mstarlinuxinput,mstarir,mstarkeypad,mstarloopbackinput \
                --enable-shared \
                --enable-static \
                --enable-multi \
                --with-tests=yes \
                --disable-fbdev \
                --disable-x11 \
                --disable-vnc \
                --disable-sdl \
                --enable-devmem \
                --enable-ion \
                --disable-pmem \
                --enable-hwdecodejpeg\
                --disable-hwdecodegif\
                --enable-hwdecodepng\
                --disable-OBAMA_BUILD

#sed -i 's/ECHO/echo/g' libtool
}

LIBRARY_NAME="directfb"
LIBRARY_VERSION="1.4.2m"
PACKAGE_NAME="${LIBRARY_NAME}-${LIBRARY_VERSION}"
PACKAGE_PATH=../../


OUTPUT_DIR="${DESTDIR}/${MST_PREFIX}"
echo $OUTPUT_DIR
echo $MST_PREFIX

function package()
{
    if [ "$1" != "" ]; then
        PACKAGE_PATH=$1
    fi
    echo "PACKAGE_PATH=$PACKAGE_PATH"

    RETURN_PATH=`pwd`
    cd $PACKAGE_PATH
    mkdir -p $PACKAGE_NAME/bin
    mkdir -p $PACKAGE_NAME/include
    mkdir -p $PACKAGE_NAME/lib/pkgconfig
    mkdir -p $PACKAGE_NAME/share/man/man1
    mkdir -p $PACKAGE_NAME/share/man/man5
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/libdirect-1.4.so.0.2.0
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/libdirectfb-1.4.so.0.2.0
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/libfusion-1.4.so.0.2.0
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/gfxdrivers/libdirectfb_mstar_g2.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/gfxdrivers/libdirectfb_mstar.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/inputdrivers/libdirectfb_mstar_linux_input.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/inputdrivers/libdirectfb_mstar_loopback_input.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/inputdrivers/libdirectfb_mstarir.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/inputdrivers/libdirectfb_mstarkeypad.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/wm/libdirectfbwm_default.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/systems/libdirectfb_devmem.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/systems/libdirectfb_pmem.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/interfaces/IDirectFBFont/libidirectfbfont_default.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/interfaces/IDirectFBFont/libidirectfbfont_dgiff.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/interfaces/IDirectFBFont/libidirectfbfont_ft2.so      
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/interfaces/IDirectFBFont/libidirectfbfont_mstarbmp.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/interfaces/IDirectFBImageProvider/libidirectfbimageprovider_dfiff.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/interfaces/IDirectFBImageProvider/libidirectfbimageprovider_gif.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/interfaces/IDirectFBImageProvider/libidirectfbimageprovider_jpeg.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/interfaces/IDirectFBImageProvider/libidirectfbimageprovider_gopc.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/interfaces/IDirectFBImageProvider/libidirectfbimageprovider_mif.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/interfaces/IDirectFBImageProvider/libidirectfbimageprovider_png.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/interfaces/IDirectFBImageProvider/libidirectfbimageprovider_vec.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/interfaces/IDirectFBVideoProvider/libidirectfbvideoprovider_gif.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/interfaces/IDirectFBVideoProvider/libidirectfbvideoprovider_gopc.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/interfaces/IDirectFBVideoProvider/libidirectfbvideoprovider_v4l.so
    arm-none-linux-gnueabi-objcopy --add-section .mmodule_version=$RETURN_PATH/version_info $OUTPUT_DIR/lib/directfb-1.4-0/interfaces/IDirectFBVideoProvider/libidirectfbvideoprovider_vec.so
    cp -vrfP $OUTPUT_DIR/directfb_examples $PACKAGE_NAME
    cp -vrfP $OUTPUT_DIR/bin/dfb* $PACKAGE_NAME/bin
    cp -vrfP $OUTPUT_DIR/bin/direct* $PACKAGE_NAME/bin
    cp -vrfP $OUTPUT_DIR/bin/directfb* $PACKAGE_NAME/bin
    cp -vrfP $OUTPUT_DIR/bin/fusion* $PACKAGE_NAME/bin
    cp -vrfP $OUTPUT_DIR/bin/mkdfiff $PACKAGE_NAME/bin
    cp -vrfP $OUTPUT_DIR/bin/mkdgiff $PACKAGE_NAME/bin
    cp -vrfP $OUTPUT_DIR/include/directfb $PACKAGE_NAME/include
    cp -vrfP $OUTPUT_DIR/include/directfb-internal $PACKAGE_NAME/include
    cp -vrfP $OUTPUT_DIR/lib/directfb-1.4-0 $PACKAGE_NAME/lib
    cp -vrfP $OUTPUT_DIR/lib/libdirect* $PACKAGE_NAME/lib
    cp -vrfP $OUTPUT_DIR/lib/libfusion* $PACKAGE_NAME/lib
    cp -vrfP $OUTPUT_DIR/lib/pkgconfig/direct* $PACKAGE_NAME/lib/pkgconfig
    cp -vrfP $OUTPUT_DIR/lib/pkgconfig/fusion* $PACKAGE_NAME/lib/pkgconfig
    cp -vrfP $OUTPUT_DIR/share/directfb-* $PACKAGE_NAME/share
    cp -vrfP $OUTPUT_DIR/share/man/man1/dfb* $PACKAGE_NAME/share/man/man1
    cp -vrfP $OUTPUT_DIR/share/man/man1/directfb* $PACKAGE_NAME/share/man/man1
    cp -vrfP $OUTPUT_DIR/share/man/man5/directfb* $PACKAGE_NAME/share/man/man5
    tar -zvcf $PACKAGE_NAME.tar.gz $PACKAGE_NAME
    rm -rf $PACKAGE_NAME
    cd $RETURN_PATH
}

case $1 in
"package")
    echo "################  pacakage $LIBRARY_NAME"
    package $2
    ;;
*)
    echo "################  building $LIBRARY_NAME"
    build $1
    ;;
esac
