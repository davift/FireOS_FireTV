#!/bin/sh


source /tools/ToolChainSetting SourceryArm_472;
echo $PATH;
export DFB_PATH="$(pwd)/vendor/dfb/dfb1.4.2/";
export SUPERNOVA_ROOT=$(pwd);
echo DFB path is $DFB_PATH;
echo SUPERNOVA ROOT is $SUPERNOVA_ROOT;

chmod 777 -R .;

echo "cd to supernova/project";
cd ./projects/;
echo "source buildsetting/build_Manhattan_232A_ROM_EMMC_DVB.sh";
source ./buildsettings/build_Manhattan_232A_ROM_EMMC_DVB.sh ;
echo "make setup & make extralibs & make utopia";
make setup;
make extralibs;
make utopia;

echo "cd to dfb1.4.2";
cd $SUPERNOVA_ROOT/vendor/dfb/dfb1.4.2/;

chmod 777 -R .;

libtoolize -f;
sed -i 's/DFB_PATH=.*/DFB_PATH="$DFB\_PATH"/g' ./BuildScript/Arm_mstconfigure_muf.sh;
sed -i 's/SUPERNOVA_ROOT=.*/SUPERNOVA_ROOT="$SUPERNOVA\_ROOT"/g' ./BuildScript/Arm_mstconfigure_muf.sh;
sed -i 's/CHIP=.*/CHIP=manhattan/g' ./BuildScript/Arm_mstconfigure_muf.sh;
sed -i 's/UTOPIA_INCLUDE_PATH=.*/UTOPIA_INCLUDE_PATH="$SUPERNOVA\_ROOT\/develop\/include\/utopia"/g' ./BuildScript/Arm_mstconfigure_muf.sh;

echo "source ./BuildScript/Arm_mstconfigure_muf.sh";
source ./BuildScript/Arm_mstconfigure_muf.sh;

make all;
