#!/bin/bash


TOOL_CHAIN_PREFIX="arm-none-linux-gnueabi-"
CFLAGS_SETTINGS="-fPIC -shared -mlittle-endian -march=armv7-a -mfpu=vfpv3 -mfloat-abi=soft"
LDFLAGS_SETTINGS="-fPIC -shared -mlittle-endian -march=armv7-a -mfpu=vfpv3 -mfloat-abi=soft"
HOST="arm-none-linux-gnueabi"
DEBUG_FLAGS="-g"

function build()
{
test -z $MST_PREFIX && echo "  The MST_PREFIX must be set to proceed!!" && exit 0
echo "MST_PREFIX=$MST_PREFIX"

if [ "$MVK_VERSION" == "RELEASE" ]; then
    export CC="${TOOL_CHAIN_PREFIX}gcc ${CFLAGS_SETTINGS}"
else
    export CC="${TOOL_CHAIN_PREFIX}gcc ${CFLAGS_SETTINGS} ${DEBUG_FLAGS}"
fi
echo "CC=$CC"

./configure --prefix=$MST_PREFIX --enable-shared --enable-static --host=$HOST
#./configure --prefix=$MST_PREFIX
}

LIBRARY_NAME="libiconv"
LIBRARY_VERSION="1.13.1"
PACKAGE_NAME="${LIBRARY_NAME}-${LIBRARY_VERSION}"
PACKAGE_PATH=../../

function package()
{
    if [ "$1" != "" ]; then
        PACKAGE_PATH=$1
    fi
    echo "PACKAGE_PATH=$PACKAGE_PATH"

    RETURN_PATH=`pwd`
    cd $PACKAGE_PATH
    mkdir -p $PACKAGE_NAME/bin
    mkdir -p $PACKAGE_NAME/include
    mkdir -p $PACKAGE_NAME/lib
    mkdir -p $PACKAGE_NAME/share/doc/libiconv
    mkdir -p $PACKAGE_NAME/share/locale
    mkdir -p $PACKAGE_NAME/share/man/man1
    mkdir -p $PACKAGE_NAME/share/man/man3
    cp -rfP $MST_PREFIX/bin/iconv $PACKAGE_NAME/bin
    cp -rfP $MST_PREFIX/include/iconv.h $PACKAGE_NAME/include
    cp -rfP $MST_PREFIX/include/libcharset.h $PACKAGE_NAME/include
    cp -rfP $MST_PREFIX/include/localcharset.h $PACKAGE_NAME/include
    cp -rfP $MST_PREFIX/lib/libcharset.* $PACKAGE_NAME/lib
    cp -rfP $MST_PREFIX/lib/libiconv.* $PACKAGE_NAME/lib
    cp -rfP $MST_PREFIX/lib/preloadable_libiconv.so $PACKAGE_NAME/lib
    cp -rfP $MST_PREFIX/share/doc/libiconv/iconv* $PACKAGE_NAME/share/doc/libiconv
    cp -rfP $MST_PREFIX/share/locale/* $PACKAGE_NAME/share/locale
    cp -rfP $MST_PREFIX/share/man/man1/* $PACKAGE_NAME/share/man1
    cp -rfP $MST_PREFIX/share/man/man3/* $PACKAGE_NAME/share/man3
    tar -zvcf $PACKAGE_NAME.tar.gz $PACKAGE_NAME
    rm -rf $PACKAGE_NAME
    cd $RETURN_PATH
}

case $1 in
"package")
    echo "################  pacakage $LIBRARY_NAME"
    package $2
    ;;
*)
    echo "################  building $LIBRARY_NAME"
    build
    ;;
esac
