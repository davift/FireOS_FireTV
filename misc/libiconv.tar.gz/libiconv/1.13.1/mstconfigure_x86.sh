#!/bin/bash

test -z $MST_PREFIX && echo "  The MST_PREFIX must be set to proceed!!" && exit 0
echo "MST_PREFIX=$MST_PREFIX"

./configure --prefix=$MST_PREFIX --enable-shared --enable-static
