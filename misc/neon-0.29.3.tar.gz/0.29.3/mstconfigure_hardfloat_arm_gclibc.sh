#!/bin/bash

TOOL_CHAIN_PREFIX="arm-buildroot-linux-uclibcgnueabi-"
TOOL_CHAIN_PATH="/tools/arm/arm-uclibc-2013-02"

#CFLAGS_SETTINGS="-fPIC -shared -mlittle-endian -march=armv7-a -mfpu=vfpv3 -mfloat-abi=softfp"
#LDFLAGS_SETTINGS="-fPIC -shared"
			

CFLAGS_SETTINGS="-nostdinc -Os -funit-at-a-time -fmerge-all-constants -fstrict-aliasing -fno-tree-loop-optimize \
			-fno-tree-dominator-opts -fno-strength-reduce -funsigned-char -fno-builtin -mfpu=vfpv3 -mfloat-abi=softfp -mthumb-interwork\
			-mlittle-endian  -Wall -Wstrict-prototypes -Wstrict-aliasing -D_GNU_SOURCE=1   \
			-I$TOOL_CHAIN_PATH/usr/include/ \
			-I$TOOL_CHAIN_PATH/gcc/4.6.3/lib/gcc/arm-buildroot-linux-uclibcgnueabi/4.6.3/include/ \
			-I$TOOL_CHAIN_PATH/gcc/4.6.3/lib/gcc/arm-buildroot-linux-uclibcgnueabi/4.6.3/include-fixed/ \
			-I$TOOL_CHAIN_PATH/gcc/4.6.3/arm-buildroot-linux-uclibcgnueabi/include/c++/4.6.3/tr1/ \
			-I$TOOL_CHAIN_PATH/gcc/4.6.3/arm-buildroot-linux-uclibcgnueabi/include/c++/4.6.3/"
			
LDFLAGS_SETTINGS="-Wl,-EL \
           -Wl,-z,now \
           -Wl,-s -B/opt/tools/arm-uclibc/lib \
           -Wl,-rpath,$TOOL_CHAIN_PATH/lib \
           -Wl,-rpath-link,$TOOL_CHAIN_PATH/lib \
           -Wl,-rpath,$TOOL_CHAIN_PATH/ \
           -Wl,--dynamic-linker,$TOOL_CHAIN_PATH/lib/ld-uClibc.so.0 -lcrypto -lssl -lxml2 -lz \
           -L$TOOL_CHAIN_PATH/usr/lib/ "
           

DEBUG_FLAGS="-g"

BUILD="i386-linux"
HOST="arm-none-linux"



function build()
{
test -z $MST_PREFIX && echo "  The MST_PREFIX must be set to proceed!!" && exit 0
echo "MST_PREFIX=$MST_PREFIX"

if [ "$MVK_VERSION" != "RELEASE" ]; then
    CFLAGS_SETTINGS="${CFLAGS_SETTINGS} ${DEBUG_FLAGS}"
fi

export CC="${TOOL_CHAIN_PREFIX}gcc "
echo "CC=$CC"

./configure --prefix=$MST_PREFIX \
            --build=$BUILD \
            --host=$HOST \
            --with-libs=$MST_PREFIX \
            CFLAGS="-I$MST_PREFIX/include $CFLAGS_SETTINGS -I$MST_PREFIX/include/libxml2 -I$MST_PREFIX/include/zlib" \
            LDFLAGS="-L$MST_PREFIX/lib $LDFLAGS_SETTINGS" \
            --with-libxml2 \
            --enable-shared \
            --enable-static \
            --with-ssl=openssl
}

LIBRARY_NAME="neon"
LIBRARY_VERSION="0.29.3"
PACKAGE_NAME="${LIBRARY_NAME}-${LIBRARY_VERSION}"
PACKAGE_PATH=../../

function package()
{
    if [ "$1" != "" ]; then
        PACKAGE_PATH=$1
    fi
    echo "PACKAGE_PATH=$PACKAGE_PATH"

    RETURN_PATH=`pwd`
    cd $PACKAGE_PATH
    mkdir -p $PACKAGE_NAME/bin
    mkdir -p $PACKAGE_NAME/include
    mkdir -p $PACKAGE_NAME/include/neon
    mkdir -p $PACKAGE_NAME/lib/pkgconfig
    mkdir -p $PACKAGE_NAME/share/

    cp -vrfP $RETURN_PATH/neon-config $PACKAGE_NAME/bin    
    cp -vrfP $RETURN_PATH/src/ne*.h $PACKAGE_NAME/include/neon    
    cp -vrfP $RETURN_PATH/src/.libs/libneon.* $PACKAGE_NAME/lib    
    cp -vrfP $RETURN_PATH/neon.pc $PACKAGE_NAME/lib/pkgconfig    
    cp -vrfP $RETURN_PATH/doc/html $PACKAGE_NAME/share/doc   
    cp -vrfP $RETURN_PATH/doc/man $PACKAGE_NAME/share/

    tar -zvcf $PACKAGE_NAME.tar.gz $PACKAGE_NAME
    rm -rf $PACKAGE_NAME
    cd $RETURN_PATH
}

case $1 in
"package")
    echo "################  pacakage $LIBRARY_NAME"
    package $2
    ;;
*)
    echo "################  building $LIBRARY_NAME"
    build
    ;;
esac
