#!/bin/bash

# Chip
CHIP="titania2"

test -z $MST_PREFIX && echo "  The MST_PREFIX must be set to proceed!!" && exit 0

echo "MST_PREFIX=$MST_PREFIX" 

test -z $TOOL_CHAIN_PREFIX && export TOOL_CHAIN_PREFIX=mips2_fp_le-

echo "TOOL_CHAIN_PREFIX=$TOOL_CHAIN_PREFIX" 



# **********************************************
# Tool Chain
# **********************************************
CROSS_TOOL_PREFIX=$TOOL_CHAIN_PREFIX

if [ "$CROSS_TOOL_PREFIX" == "mips-linux-gnu-" ]; then
    CC=${CROSS_TOOL_PREFIX}"gcc -EL"
else
    CC=${CROSS_TOOL_PREFIX}"gcc"
fi

export CC

./configure --prefix=$MST_PREFIX \
            --build=i386-linux \
            --host=mipsel-unknown-linux-gnu \
            CFLAGS="-I$MST_PREFIX/include" \
            LDFLAGS="-L$MST_PREFIX/lib" \
            --with-libs=$MST_PREFIX \
            --with-libxml2 \
            --with-ssl=openssl \
            --enable-shared=yes \
            --enable-static=no \
