
#if !defined(CRChecker_H)
#define CRChecker_H
#ifdef __cplusplus
extern "C" {
#endif

#include <openssl/ocsp.h>
typedef enum {
	E_CERTSTATUS_GOOD,		//map to V_OCSP_CERTSTATUS_GOOD
	E_CERTSTATUS_REVOKED,		//map to V_OCSP_CERTSTATUS_REVOKED
	E_CERTSTATUS_UNKNOWN		//map to V_OCSP_CERTSTATUS_UNKNOWN or Invalid OCSP Response or //any failures during CRL check
} EN_CR_RESULT;

typedef enum {
	E_CRCHECKER_NONE = 0,
	E_CRCHECKER_OCSP = 1,
	E_CRCHECKER_OCSP_STAPLING = 2,
	E_CRCHECKER_CRLSET = 4,
	E_CRCHECKER_noCRLSET=E_CRCHECKER_OCSP | E_CRCHECKER_OCSP_STAPLING,
	E_CRCHECKER_noOCSP=E_CRCHECKER_OCSP_STAPLING | E_CRCHECKER_CRLSET,
	E_CRCHECKER_noSTAPLING=E_CRCHECKER_OCSP | E_CRCHECKER_CRLSET,
	E_CRCHECKER_ALL = E_CRCHECKER_OCSP | E_CRCHECKER_OCSP_STAPLING | E_CRCHECKER_CRLSET
} EN_CRCHECKER_MODE;



/*! \fn int (*httpGet)(const char* url, const char* header, char** response, int timeout)
 *  \brief Send HTTP GET request and get response synchronously
 *  \param url The destination URL.
 *  \param header Specific header fields to add. Formats like: "Accept-Encoding: gzip, deflate\r\nAccept-Language: zh-TW".
 *  \param response The body of response.
 *  \param timeout The timeout of data transmission
 *  \return The length of response
 */
typedef int (*httpGet)(const char *url, const char *header, char **response, int timeout);


/*! \fn int (*httpPost)(const char* url, const char* header, const char* data, char** response, int timeout)
 *  \brief Send HTTP POST request and get response synchronously
 *  \param url The destination URL.
 *  \param header Specific header fields to add. Formats like: "Accept-Encoding: gzip, deflate\r\nAccept-Language: zh-TW".
 *  \param response The body of response.
 *  \param timeout The timeout of data transmission
 *  \return The length of response
 */
typedef int (*httpPost)(const char* url, const char* header, const char* data, int length, char** response, int timeout);

//public API
int CRChecker(SSL_CTX* ctx, SSL* ssl, httpGet httpGet, httpPost httpPost, EN_CRCHECKER_MODE mode);
void setCertStore(X509_STORE* store);

//return true or false
int doVerify(STACK_OF(X509)* peerCertChain);
int CRC_doVerify(STACK_OF(X509)* peerCertChain, char *ca_cert_path);

#ifdef __cplusplus
}
#endif
#endif //OCSP_CHECKER_H

