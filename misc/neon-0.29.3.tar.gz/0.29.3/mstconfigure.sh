#!/bin/bash

TOOL_CHAIN_PREFIX="${CROSS_COMPILE}"
CFLAGS_SETTINGS="${MSTAR_CFLAG} -fPIC"
LDFLAGS_SETTINGS="${MSTAR_LDFLAG} -fPIC"
DEBUG_FLAGS="-g"

BUILD="i386-linux"
HOST="${CROSS_COMPILE/%-/}"

function configure()
{
test -z "$MST_PREFIX" && echo "  The MST_PREFIX must be set to proceed!!" && exit 0
test -z "$MSTAR_CFLAG" && echo -e "\033[41;33m Please use \"source /tool/ToolChainSetting [toolchain]\" to set toolchain!\033[0m" && exit 0
echo "MST_PREFIX=$MST_PREFIX"

if [ "$MVK_VERSION" != "RELEASE" ]; then
    CFLAGS_SETTINGS="${CFLAGS_SETTINGS} ${DEBUG_FLAGS}"
fi

if [[ ${TOOL_CHAIN_PREFIX} =~ "mips" ]]
then
export CC="${TOOL_CHAIN_PREFIX}gcc -EL ${CFLAGS}"
else
export CC="${TOOL_CHAIN_PREFIX}gcc ${CFLAGS}"
CFLAGS_SETTINGS="${CFLAGS_SETTINGS} -shared -g"
LDFLAGS_SETTINGS="${LDFLAGS_SETTINGS} -shared"
fi
echo "CC=$CC"

./configure --prefix=$MST_PREFIX \
            --build=$BUILD \
            --host=$HOST \
            --with-libs=$MST_PREFIX \
            --with-libxml2 \
            CFLAGS="-I$MST_PREFIX/include $CFLAGS_SETTINGS -I$PWD/inc" \
            LDFLAGS="-L$MST_PREFIX/lib $LDFLAGS_SETTINGS" \
            --enable-shared \
            --enable-static \
            --with-ssl=openssl
}

LIBRARY_NAME="neon"
LIBRARY_VERSION="0.29.3"
PACKAGE_NAME="${LIBRARY_NAME}-${LIBRARY_VERSION}"
PACKAGE_PATH=../../

function build()
{
make clean
make
}

function install()
{
make install
}

function package()
{
    if [ "$1" != "" ]; then
        PACKAGE_PATH=$1
    fi
    echo "PACKAGE_PATH=$PACKAGE_PATH"

    RETURN_PATH=`pwd`
    cd $PACKAGE_PATH
    mkdir -p $PACKAGE_NAME/bin
    mkdir -p $PACKAGE_NAME/include
    mkdir -p $PACKAGE_NAME/lib/pkgconfig
    mkdir -p $PACKAGE_NAME/share/locale/cs/LC_MESSAGES
    mkdir -p $PACKAGE_NAME/share/locale/de/LC_MESSAGES
    mkdir -p $PACKAGE_NAME/share/locale/fr/LC_MESSAGES
    mkdir -p $PACKAGE_NAME/share/locale/ja/LC_MESSAGES
    mkdir -p $PACKAGE_NAME/share/locale/nn/LC_MESSAGES
    mkdir -p $PACKAGE_NAME/share/locale/pl/LC_MESSAGES
    mkdir -p $PACKAGE_NAME/share/locale/ru/LC_MESSAGES
    mkdir -p $PACKAGE_NAME/share/locale/tr/LC_MESSAGES
    mkdir -p $PACKAGE_NAME/share/locale/zh_CN/LC_MESSAGES
    mkdir -p $PACKAGE_NAME/share/man/man1
    mkdir -p $PACKAGE_NAME/share/man/man3
    cp -vrfP $MST_PREFIX/bin/neon-config $PACKAGE_NAME/bin
    cp -vrfP $MST_PREFIX/include/neon $PACKAGE_NAME/include
    cp -vrfP $MST_PREFIX/lib/libneon.* $PACKAGE_NAME/lib
    cp -vrfP $MST_PREFIX/lib/pkgconfig/neon.pc $PACKAGE_NAME/lib/pkgconfig
    cp -vrfP $MST_PREFIX/share/doc/neon-$LIBRARY_VERSION $PACKAGE_NAME/share/doc
    cp -vrfP $MST_PREFIX/share/locale/cs/LC_MESSAGES/neon.mo $PACKAGE_NAME/share/locale/cs/LC_MESSAGES
    cp -vrfP $MST_PREFIX/share/locale/de/LC_MESSAGES/neon.mo $PACKAGE_NAME/share/locale/de/LC_MESSAGES
    cp -vrfP $MST_PREFIX/share/locale/fr/LC_MESSAGES/neon.mo $PACKAGE_NAME/share/locale/fr/LC_MESSAGES
    cp -vrfP $MST_PREFIX/share/locale/ja/LC_MESSAGES/neon.mo $PACKAGE_NAME/share/locale/ja/LC_MESSAGES
    cp -vrfP $MST_PREFIX/share/locale/nn/LC_MESSAGES/neon.mo $PACKAGE_NAME/share/locale/nn/LC_MESSAGES
    cp -vrfP $MST_PREFIX/share/locale/pl/LC_MESSAGES/neon.mo $PACKAGE_NAME/share/locale/pl/LC_MESSAGES
    cp -vrfP $MST_PREFIX/share/locale/ru/LC_MESSAGES/neon.mo $PACKAGE_NAME/share/locale/ru/LC_MESSAGES
    cp -vrfP $MST_PREFIX/share/locale/tr/LC_MESSAGES/neon.mo $PACKAGE_NAME/share/locale/tr/LC_MESSAGES
    cp -vrfP $MST_PREFIX/share/locale/zh_CN/LC_MESSAGES/neon.mo $PACKAGE_NAME/share/locale/zh_CN/LC_MESSAGES
    cp -vrfP $MST_PREFIX/share/man/man1/neon-* $PACKAGE_NAME/share/man/man1
    cp -vrfP $MST_PREFIX/share/man/man3/ne_* $PACKAGE_NAME/share/man/man3
    cp -vrfP $MST_PREFIX/share/man/man3/neon* $PACKAGE_NAME/share/man/man3
    tar -zvcf $PACKAGE_NAME.tar.gz $PACKAGE_NAME
    rm -rf $PACKAGE_NAME
    cd $RETURN_PATH
}

case $1 in
"package")
    echo "################  pacakage $LIBRARY_NAME"
    package $2
    ;;
"make")
    echo "################  building $LIBRARY_NAME"
    build
    ;;
"install")
    echo "################  installing $LIBRARY_NAME"
    install
    ;;
*)
    echo "################  configuring $LIBRARY_NAME"
    configure
    ;;
esac
